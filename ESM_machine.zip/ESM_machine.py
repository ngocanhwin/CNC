import threading
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk
import serial
#from serial import *
#import time, os, tkinter
#import shutil

Version = 'EMA cnc _E3.3'
reading = False
STT = 0
he_so_chinh_toc_do = 1
X_max = 460.00
hanh_trinh_X = 0.00
may = 'M1'
e_lock = False
if may == 'S3':
    max_feed = ' F2500 \n'
else:
    max_feed = ' F1500 \n'

ser = serial.Serial()
ser.baudrate = 115200

def makecenter(root):
    root.update_idletasks()
    width = root.winfo_width()
    height = root.winfo_height()
    x = (root.winfo_screenwidth() // 2) - (width // 2)
    y = (root.winfo_screenheight() // 2) - (height // 2)
    root.geometry('{}x{}+{}+{}'.format(width, height, x, y))

def loi_ket_noi():
    top = tkinter.Toplevel()
    top.configure(width=guiFrame.screenwidth, height=guiFrame.screenheight)
    makecenter(top)
    La = Label(top, text='LỖI 0000 !!!', font='Tahoma, 20')
    La.pack()
    La.place(x=150, y=200)
    B = Button(top, text='Bỏ qua', font='Tahoma, 20', command=guiFrame.update_copy_gcode)#vao he thong
    B.pack()
    B.place(width=200, height=50, x=100, y=300)
    B = Button(top, text='Tắt máy', font='Tahoma, 20', command=guiFrame.turn_off)#os.system('/usr/bin/sudo /sbin/shutdown -h now'))
    B.pack()
    B.place(width=200, height=50, x=500, y=300)

def connectSerial():
    try:
        ser.flushInput()
        ser.flushOutput()
        count = 0
        while True:
            string = ser.readline()
            # print(string)
            if 'sanxuattudong' in str(string):
                PASS = 1
                break

            else:
                count += 1
                if count == 10:
                    loi_ket_noi()
    except:
        loi_ket_noi()

def checkSum(cline):
    csum = 0
    for i in range(0, len(cline), 1):
        csum = csum ^ ord(cline[i])

    return csum


def sendLine(sline):
    jog_line = sline + '\n'
    guiFrame.printJogLine(jog_line)
    string = sline + '#'
    ser.write(string.encode())


def writeline(wline):
    OK = False
    wline = wline.strip()
    wline = wline + '*' + str(checkSum(wline))
    sendLine(wline)
    while not OK:
        wRespond = ser.readline()
        print (wRespond)
        if 'ok' in str(wRespond):
            jog_line = 'Line Processed\n'
            OK = True
        elif 'ready!' in str(wRespond): #neu ok
            print('ready!')
        elif 'not clamped!' in str(wRespond): #neu chua kep
            print('not clamped!')
        elif 'lift_limit_high!' in str(wRespond): #neu chua ha cu chan
            print('lift_limit_high!')
        elif 'not closed lid!' in str(wRespond): #neu chua dong nap
            print('not closed lid!')
        elif 'sanxuattudong' in str(wRespond): #neu dang chay ma nhan stop thi pi nhan duoc chuoi nay
            ser.write('puss_stop !!! \\'.encode()) # gui dong nay de nhan lai 'Unknown command' va thoat khoi for trong ham Start
            # os.system('sudo reboot')
            # guiFrame.stop = True # khong co tac dung nhu trong elif 'Unknown command', tai sao?
            global reading
            reading = False # cho phep bam chon trong canvas
            print('puss_stop !!!')
        elif 'Unknown command' in str(wRespond): #neu chua dong nap
            guiFrame.stop = True # thoat khoi vong for trong ham Start de lam cho cac nut nhan tro lai trang thai nomal
            ser.write(('M107\\').encode())
        elif str(wRespond) == '':
            print('...')
        else:
            OK = False

def jog_writeline(wline): # khi chay jog phai bo dong lenh: wline = wline + '*' + str(checkSum(wline)) ___tai sao?
    OK = False
    wline = wline.strip()
    #wline = wline + '*' + str(checkSum(wline))
    sendLine(wline)
    while not OK:
        wRespond = ser.readline()
        if 'ok' in str(wRespond):
            jog_line = 'Line Processed\n'
            OK = True
        elif str(wRespond) == '':
            pass
        else:
            OK = False

def START():
    global reading
    global selected
    selected = True
    
    while selected == True:

        filename = guiFrame.fname
        
        #print ('filename', filename)
        if filename != '':
            guiFrame.SHUTDOWN.configure(state='disabled')
            guiFrame.UPDATE.configure(state='disabled')
            guiFrame.MOVEXYZ.configure(state='disabled')
            guiFrame.START.configure(state='disabled')
            guiFrame.RESET.configure(state='disabled')
            reading = True
            f = open(filename, 'r')
            nd_file = f.readlines()
            f.close()

            for line in nd_file:
                if guiFrame.stop:
                    guiFrame.fname = ''
                    break
                
                else:
                    line.strip()
                    if ';' in line:
                        line = line[0:line.index(';')]
                    if line != '' and line != '\n':
                        line_to_list = line.split()
                        # print(type(line_to_list), line_to_list)
                        for text in line_to_list:
                            if 'X_max' in text:
                                line_to_list[line_to_list.index(text)] = 'X' + str(X_max)
                                line = ''
                                for text in line_to_list:
                                    line = line + text + ' '
                            elif 'X_min' in text:
                                X_min = 'X' + str(X_max - hanh_trinh_X)
                                line_to_list[line_to_list.index(text)] = X_min
                                # print(line_to_list)
                                line = ''
                                for text in line_to_list:
                                    line = line + text + ' '
                            elif 'F' in text:
                                text = text.replace('F', '')
                                # print('toc do: ', text)
                                if text.isdigit(): tocDo = int(text)
                                # print(int(tocDo*he_so_chinh_toc_do))
                                if may == 'M1' or may == 'M2' or may == 'M3' or may == 'M4' or may == 'M5':
                                    tocDoDieuChinh = int(tocDo * he_so_chinh_toc_do)
                                    # print(tocDoDieuChinh)
                                else:
                                    if tocDo < 500: #toc do chay cat
                                        tocDoDieuChinh = int(tocDo * he_so_chinh_toc_do)
                                    else:
                                        tocDoDieuChinh = tocDo
                                        # print(tocDoDieuChinh)
                                text = 'F' + str(tocDoDieuChinh)
                                line_to_list.pop(len(line_to_list)-1)
                                line_to_list.append(text)
                                # print(line_to_list)
                                line = ''
                                for text in line_to_list:
                                    line = line+text+' '
                        print(line)
                        writeline(line)

            guiFrame.fname = ''
            reading = False
            
            guiFrame.SHUTDOWN.configure(state='normal')
            guiFrame.UPDATE.configure(state='normal')
            guiFrame.MOVEXYZ.configure(state='normal')
            guiFrame.START.configure(state='normal')
            guiFrame.RESET.configure(state='normal')
        time.sleep(1)


thread = threading.Thread(target=START)

def flushSerial():
    if ser.isOpen():
        ser.flushInput()
        ser.flushOutput()


loai_nhom = []

class GUIFramework(Frame):
    """This is the GUI"""

    filename = ''
    dirname = ''
    X, Y, Z, E = (0.0, 0.0, 0.0, 0.0)    
    start_in_thread = 0
    stop = True
    running_jog = False
    fname = ''
    if may == 'M1':
        vung_cat_truoc = '' # bien luu ten vung cat chon truoc khi click
        thong_tin_sua_code = [] # list luu thong tin chinh sua cac vung cat
    # path = os.getcwd() + '/gcode/' #PC
    # path2 = os.getcwd() + '/data/'  # PC

    try:
        path = '/home/pi/Documents/' #RPI
        os.listdir(path)
    except:
        path = os.getcwd() + '/gcode/' #PC
    try:
        path2 = '/home/pi/data/' #RPI
        os.listdir(path2)
    except:
        path2 = os.getcwd() + '/data/'  # PC
    current_entry = None
    mau_pk_m1 = []
    mau_pk_m2 = []
    
    
    
    ds_folder = []
    def tao_ds_folder(self):
        ds_file_folder = os.listdir(self.path)
    
        for ds in ds_file_folder:        
            if os.path.isdir(self.path + ds):
                self.ds_folder.append(ds)

    def __init__(self, master=None):
        """Initialize yourself"""
        Frame.__init__(self, master)
        self.master.title('EMA G CODE SENDER')
        self.master.wm_attributes('-fullscreen', 'true')
        self.grid(padx=0, pady=0, sticky=E + N)

        '''tự nhận kích thước màn hình'''
        self.screenwidth = self.master.winfo_screenwidth()
        self.screenheight = self.master.winfo_screenheight()

        if self.screenwidth > 1024: self.screenwidth = 1024
        if self.screenheight > 600: self.screenheight = 600

        #self.screenwidth = 800
        #self.screenheight = 480
        #print('screen: ', self.screenwidth, self.screenheight)

        self.notebook = ttk.Notebook(self.master)
        self.notebook.grid()

        self.page1_control = ttk.Frame(self.notebook)  # Adds tab 1 of the notebook
        self.notebook.add(self.page1_control)

        self.page2_G_code_M = ttk.Frame(self.notebook)  # Adds tab 1 of the notebook
        self.notebook.add(self.page2_G_code_M)
        if may == 'S3' or may == 'E3':
            self.CreateWidgets_S3E3_page1(self.page1_control)
        elif may == 'M1':
            self.CreateWidgets_M1_page1(self.page1_control)
        self.CreateWidgets_page2(self.page2_G_code_M)
        makecenter(self.master)

    def flushSerial(self):
        ser.flushInput()
        ser.flushOutput()

    def create_dir_menu(self, canvas):        
        canvas.delete('all')
        y = 30
        for dirname in self.ds_folder:
            dirname_rewrite = dirname.replace(' ', '^')
            # print (dirname)
            frame = canvas.create_rectangle(5, y - 24, self.screenwidth*2/5-5, y + 24, outline='orange', fill='orange', tag=dirname_rewrite)
            canvas.create_text(30, y, text=dirname, font='Tahoma, 16', anchor='w') # w: can le trai, e: can le phai
            y += 50
        

    def create_file_menu(self, canvas, selected_dir):
        loai_nhom[:] = []
        list_files = os.listdir(self.path + selected_dir)
        for name in list_files:
            for name in list_files:
                if '.gcode' not in name:
                    list_files.remove(name)

        print (list_files)
        canvas.delete('all')
        y = 30
        for file_name in list_files:
            file_name = file_name.replace('.gcode', '')
            loai_nhom.append(file_name)
            file_name_rewrite = file_name.replace(' ', '^')
            frame = canvas.create_rectangle(5, y - 24, self.screenwidth*3/5-5, y + 24, outline='orange', fill='orange', tag=file_name_rewrite)
            canvas.create_text(30, y, text=file_name, font='Tahoma, 16', anchor='w')
            y += 50

    def chon_loai_pkien(self, canvas, event):
        if not reading:
            items = canvas.find_overlapping(event.x - 10, event.y - 10, event.x, event.y)
            for item in items:
                tag = canvas.gettags(item)
                if tag != ():
                    selected_dir = tag[0].replace('^', ' ')
                    if selected_dir in self.ds_folder:
                        print (selected_dir)
                        # tao hieu ung danh dau menu dang duoc chon
                        canvas.itemconfigure('all', width=0)
                        canvas.itemconfigure(item, width=2, outline='blue')
                        if 'M' not in may: # khong phai app may phay do
                            self.B_newFile.configure(state='normal') # bat che do ON cho nut 'them chuong trinh'

                        # tao danh sach file trong thu muc chon
                        if canvas == self.cv1:
                            self.create_file_menu(self.cv2, selected_dir)
                        if canvas == self.p2cv1:
                            self.create_file_menu(self.p2cv2, selected_dir)
                        self.dirname = selected_dir

    def draw_section(self, canvas): #may phay do
        'dua vao noi dung trong phan mo ta, ve mat cat do vao canvas'
        f = open(self.filename, mode='r', encoding='utf-8')
        ndfile = f.readlines()
        f.close()
        canvas.delete('all')
        points = []
        for nd_dong_i in ndfile:
            dong_i = nd_dong_i.split()
            if dong_i != []:
                if dong_i[0] == ';':
                    dong_i.pop(0)
                    tag = dong_i[0]
                    if tag == 'polygon_ngoai':
                        toa_do = dong_i[1: len(dong_i)]
                        for text in toa_do:
                            points.append(float(text))
                        # print('points = ', points)
                        canvas.create_polygon(points, outline="black", fill="gray31", tag=tag)
                        points.clear()
                    elif tag == 'polygon_trong':
                        toa_do = dong_i[1: len(dong_i)]
                        for text in toa_do:
                            points.append(float(text))
                        # print('points = ', points)
                        canvas.create_polygon(points, outline="black", fill="orange", tag=tag)
                        points.clear()
                    elif tag == 'line':
                        toa_do = dong_i[1: len(dong_i)]
                        for text in toa_do:
                            points.append(float(text))
                        canvas.create_line(points, fill='gray', tags=dong_i[1])
                        points.clear()
                    elif tag == 'cut':
                        toa_do = dong_i[2: len(dong_i)]
                        for text in toa_do:
                            points.append(float(text))
                        canvas.create_line(points, fill='blue', width=2, tags=(dong_i[0], dong_i[1]))
                        points.clear()

    def draw_cv3(self):
        'dua vao noi dung file gcode da chon, ve mo phong vao cv3'
        # print(self.filename)
        if may == 'M1' or may == 'M2' or may == 'M3' or may == 'M4' or may == 'M5':
            # ve trong page1
            self.draw_section(self.cv3)
            # di chuyen hinh ve giua canvas
            self.cv3.scale('all', 0, 0, 2, 2)
            coords = self.cv3.bbox('all')
            if coords != None:
                xt, yt = (coords[0]+coords[2])/2, (coords[1]+coords[3])/2
                xt_canvas, yt_canvas = self.screenwidth / 3 /2,  (self.screenheight - 40 - 130 - 80)/2
                self.cv3.move('all', xt_canvas-xt, yt_canvas-yt)
            # ve trong page2
            self.draw_section(self.p2cv3)
            # di chuyen hinh ve giua canvas
            self.p2cv3.scale('all', 0, 0, 2, 2)
            coords = self.p2cv3.bbox('all')
            if coords != None:
                xt, yt = (coords[0] + coords[2]) / 2, (coords[1] + coords[3]) / 2
                xt_canvas, yt_canvas = self.screenwidth / 3 / 2, (self.screenheight - 40 - 130 - 80) / 2
                self.p2cv3.move('all', xt_canvas - xt, yt_canvas - yt)
        else:
            # global tag  # text dau tien trong 1 dong
            f = open(self.filename, mode='r', encoding='utf-8')
            ndfile = f.readlines()
            f.close()
            tag = 'mat_1'
            points = []
            self.cv3.delete('all')
            # ve ra cac polygon tu nd file
            for nd_dong_i in ndfile:
                if 'E90' in nd_dong_i: #dong code chuyen tu mat 1 sang mat 2
                    points.clear()  # xoa list de xoa dong co chua toa do cua mat 2 truoc dong G1 E90 F...
                    tag = 'mat_2'
                if 'G1' in nd_dong_i and 'X' in nd_dong_i and 'Y' in nd_dong_i: # them toa do vao polygon
                    # print(nd_dong_i)
                    dong_i = nd_dong_i.split()

                    text = dong_i[1]
                    text_ed = text.replace('X', '')
                    X = float(text_ed)
                    points.append(X)
                    # print('X = ', X)

                    text = dong_i[2]
                    text_ed = text.replace('Y', '')
                    Y = float(text_ed)
                    points.append(Y)
                    # print('Y = ', Y)
                else: #ve polygon
                    if points != [] and len(points) >=6: #neu co chua it nhat la toa do 3 diem
                        self.cv3.create_polygon(points, outline="gray15", width=6, fill="gray15", tag=tag)
                        points.clear()  # xoa list
            #di chuyen cac polygon ve vi tri nhin thay duoc
            coords = self.cv3.bbox('mat_1')  # toa do cua hcn bao tat ca cac doi tuong thuoc mat 1
            if coords != None:
                self.cv3.move('mat_1', 100, -coords[1] + 20)
            coords = self.cv3.bbox('mat_2')  # toa do cua hcn bao tat ca cac doi tuong thuoc mat 1
            if coords != None:
                self.cv3.move('mat_2', 100, -coords[1]+40)
            self.cv3.scale('all', 100, 40, 1.5, 1.5)  #lay toa do x=100, y=40 lam chuan, phong to len 1.5 lan
            self.cv3.create_text(50, 25, text='Mat 1', font="Tahoma, 14")
            self.cv3.create_text(50, 60, text='Mat 2', font="Tahoma, 14")


    def chon_loai_nhom(self, canvas, event):
        #print (reading)
        if not reading:
            items = canvas.find_overlapping(event.x - 1, event.y - 1, event.x + 1, event.y + 1)
            for item in items:
                tag = canvas.gettags(item)
                #print('tag:', tag)
                if tag != () and tag[0] != 'current':
                    self.selected_file = tag[0].replace('^', ' ')
                    #print (self.selected_file)
                    if self.selected_file in loai_nhom:
                        # tao hieu ung danh dau menu dang duoc chon
                        canvas.itemconfigure('all', width=0)
                        canvas.itemconfigure(item, width=2, outline='blue')
                        
                        # tao duong dan cho file duoc chon de truyen ra ngoai (khi nhan START thi truy cap file theo path nay)
                        self.filename = self.path + self.dirname + '/' + self.selected_file + '.gcode'
                        self.draw_cv3() #sau khi da chon file, ve mo phong vao cv3


    def printJogLine(self, jogLine):
        self.feedback.insert(1.0, jogLine)
        self.p2feedback.insert(1.0, jogLine)
        self.update_idletasks()

    def thread_begin(self):
        if may == 'S3':
            ser.write(('M35 E0\\').encode())

        if may == 'M1':
            ser.write(('M1\\').encode()) #gửi lệnh để arduino kiểm tra trạng thái kẹp, cữ đã sẵn sàng hay chưa

        self.fname = self.filename
        self.stop = False
        print ('thread begin:', self.start_in_thread)
        self.flushSerial()


    def reset(self):
        os.system('sudo reboot')

    def off(self):
        global selected
        if ser.isOpen():
            ser.close()
        if thread.isAlive():
            selected = False
            thread.join()
        if thread_runJog.isAlive():
            self.hold = False
            thread_runJog.join()
        self.master.destroy()
        os.system('/usr/bin/sudo /sbin/shutdown -h now')

    def turn_off(self):
        self.top = tkinter.Toplevel(self.master)

        # self.top.minsize(width=450, height=10)

        self.B = tkinter.Button(self.top, width=15, height=5, bg='red', text='TẮT MÁY',
                                fg='white', font='Tahoma, 16', command=self.off)
        self.B.grid(row=0, column=0)
        self.B = tkinter.Button(self.top, width=15, height=5, bg='blue4', text='QUAY LẠI',
                                fg='white', font='Tahoma, 16', command=self.top.destroy)
        self.B.grid(row=0, column=1)
        self.L = tkinter.Label(self.top, text='SAU KHI TẮT MÀN HÌNH\nĐỢI 10 GIÂY TRƯỚC KHI TẮT NGUỒN',
                               font='Tahoma, 14', fg='blue')
        self.L.grid(row=1, column=0, columnspan=2)
        makecenter(self.top)

    def make_current_pos(self):
        ser.write(('M114\\').encode())
        current_position = ''
        OK = False
        notReply = 0
        while OK == False:
            ar_reaply = str(ser.readline())
            print ('ar_reaply', ar_reaply)
            if 'X:' in ar_reaply and 'Y:' in ar_reaply and 'Z:' in ar_reaply and 'Count' in ar_reaply:
                current_position = ar_reaply[0:ar_reaply.index('Count')]
                print ('current_position:', current_position)
                OK = True
            elif ar_reaply == '':
                notReply += 1
                if notReply == 10:
                    OK = True

        if current_position != '':
            xyze = ''
            for c in current_position:
                if c == 'X' or c == 'Y' or c =='Z' or c == 'E' or c =='.' or c.isdigit():
                    xyze += c
                if c == ' ':
                    if 'X' in xyze:
                        x = xyze.replace('X', '')
                        print ('X=',x)
                        self.X = float(x)
                        xyze = ''
                    elif 'Y' in xyze:
                        y = xyze.replace('Y', '')
                        print ('Y=',y)
                        self.Y = float(y)
                        xyze = ''
                    elif 'Z' in xyze:
                        z = xyze.replace('Z', '')
                        print ('Z=',z)
                        self.Z = float(z)
                        xyze = ''
                    elif 'E' in xyze:
                        e = xyze.replace('E', '')
                        print ('E=',e)
                        self.E = float(e)
                        xyze = ''

    def ask_update_copy(self):
        dialog_title = 'Có tiếp tục?'
        dialog_text = 'HỆ THỐNG SẼ TỰ KHỞI ĐỘNG LẠI ĐỂ THỰC HIỆN CHỨC NĂNG NÀY\nYes: Đồng ý\nNo: Quay lại'
        answer = messagebox.askquestion(dialog_title, dialog_text)
        if answer == 'yes':
            self.update_copy_gcode()

    def update_copy_gcode(self):
        global selected
        if ser.isOpen():
            ser.close()
        if thread.isAlive():
            selected = False
            thread.join()
        if thread_runJog.isAlive():
            self.hold = False
            thread_runJog.join()
        self.master.destroy()

    def home_xyz(self):
        if not reading:
            if may == 'S3':
                ser.write(('M35 E0\\').encode()) # mo khoa truc E
            elif may == 'M1':
                ser.write(('M38\\').encode()) # mơ khoa truc Z
            ser.write(('G28\\').encode())
            self.X, self.Y, self.Z = (0.0, 0.0, 0.0)

    def pButtonXdecrease(self, event):
        if not reading:
            if not thread_runJog.isAlive():
                thread_runJog.start()
            #print 'starting motor...'
            self.running_jog, self.Xdecrease = True, True

    def rButtonXdecrease(self, event):
        #print 'stopped motor...'
        self.running_jog, self.Xdecrease = False, False

    def pButtonXincrease(self, event):
        #if not reading:
            if not thread_runJog.isAlive():
                thread_runJog.start()
            #print ('starting motor...')
            self.running_jog, self.Xincrease = True, True

    def rButtonXincrease(self, event):
        #print 'stopped motor...'
        self.running_jog, self.Xincrease = False, False

    def pButtonYdecrease(self, event):
        if not thread_runJog.isAlive():
            thread_runJog.start()
        #print 'starting motor...'
        self.running_jog, self.Ydecrease = True, True

    def rButtonYdecrease(self, event):
        #print 'stopped motor...'
        self.running_jog, self.Ydecrease = False, False

    def pButtonYincrease(self, event):
        if not thread_runJog.isAlive():
            thread_runJog.start()
        #print 'starting motor...'
        self.running_jog, self.Yincrease = True, True

    def rButtonYincrease(self, event):
        #print 'stopped motor...'
        self.running_jog, self.Yincrease = False, False

    def pButtonZdecrease(self, event):
        if may == 'M1':
            ser.write(('M38\\').encode())
        if not thread_runJog.isAlive():
            thread_runJog.start()
        #print 'starting motor...'
        self.running_jog, self.Zdecrease = True, True
                

    def rButtonZdecrease(self, event):
        if may == 'M1':
            ser.write(('M39\\').encode())
        #print 'stopped motor...'
        self.running_jog, self.Zdecrease = False, False

    def pButtonZincrease(self, event):
        if may == 'M1':
            ser.write(('M38\\').encode())
        if not thread_runJog.isAlive():
            thread_runJog.start()
        #print 'starting motor...'
        self.running_jog, self.Zincrease = True, True

    def rButtonZincrease(self, event):
        if may == 'M1':
            ser.write(('M39\\').encode())
        #print 'stopped motor...'
        self.running_jog, self.Zincrease = False, False

    def pButtonEdecrease(self, event):
        if may == 'S3' and e_lock == True:
            top = Toplevel(bg='lightblue')
            top.wm_attributes('-fullscreen', 'true')
            Label(top, text='\n\n\n\n\nChưa mở khóa trục E !!!\n', font='Tahoma, 22', bg='lightblue').pack()
            Button(top, text='ok', font='Tahoma, 22', command=top.destroy).pack()
        else:
            if not thread_runJog.isAlive():
                thread_runJog.start()
            #print 'starting motor...'
            self.running_jog, self.Edecrease = True, True

    def rButtonEdecrease(self, event):
        #print 'stopped motor...'
        self.running_jog, self.Edecrease = False, False

    def pButtonEincrease(self, event):
        if may == 'S3' and e_lock == True:
            top = Toplevel(bg='lightblue')
            top.wm_attributes('-fullscreen', 'true')
            Label(top, text='\n\n\n\n\nChưa mở khóa trục E !!!\n', font='Tahoma, 22', bg='lightblue').pack()
            Button(top, text='ok', font='Tahoma, 22', command=top.destroy).pack()
        else:
            if not thread_runJog.isAlive():
                thread_runJog.start()
            #print 'starting motor...'
            self.running_jog, self.Eincrease = True, True

    def rButtonEincrease(self, event):
        #print 'stopped motor...'
        self.running_jog, self.Eincrease = False, False

    def holdDownButton(self):
        self.hold = True
        self.flushSerial()
        n = 0.5
        F = ' F1000#'

        while self.hold == True:
            if self.running_jog == True:
                if self.Xdecrease == True:
                    self.X -= n
                    command = 'G1 X' + str(self.X) + ' Y' + str(self.Y) + ' Z' + str(self.Z) + F
                    jog_writeline(command)
                    if self.Xtim_entry == current_entry:
                        # self.Xtim_entry.delete(0, END)
                        # self.Xtim_entry.insert(END, str(self.X))
                        self.X_tim.set(str(self.X))
                        
                elif self.Xincrease == True:
                    self.X += n
                    command = 'G1 X' + str(self.X) + ' Y' + str(self.Y) + ' Z' + str(self.Z) + F
                    jog_writeline(command)
                    if self.Xtim_entry == current_entry:
                        # self.Xtim_entry.delete(0, END)
                        # self.Xtim_entry.insert(END, str(self.X))
                        self.X_tim.set(str(self.X))
                        
                elif self.Ydecrease == True:
                    self.Y -= n
                    command = 'G1 X' + str(self.X) + ' Y' + str(self.Y) + ' Z' + str(self.Z) + F
                    jog_writeline(command)
                    if self.Y1_entry == current_entry:
                        self.Y1.set(str(self.Y))
                    elif self.Y2_entry == current_entry:
                        self.Y2.set(str(self.Y))
                        #Y3 = float(self.delta_y.get()) + float(self.delta_y.get()) - self.Y
                        #self.Y3.set(str(Y3))
                    elif may == 'S3' and self.Y3_entry == current_entry:
                        self.Y3.set(str(self.Y))

                elif self.Yincrease == True:
                    self.Y += n
                    command = 'G1 X' + str(self.X) + ' Y' + str(self.Y) + ' Z' + str(self.Z) + F
                    jog_writeline(command)
                    if self.Y1_entry == current_entry:
                        self.Y1.set(str(self.Y))
                    elif self.Y2_entry == current_entry:
                        self.Y2.set(str(self.Y))
                        #Y3 = float(self.delta_y.get()) + float(self.delta_y.get()) - self.Y
                        #self.Y3.set(str(Y3))
                    elif may == 'S3' and self.Y3_entry == current_entry:
                        self.Y3.set(str(self.Y))
                        
                elif self.Zdecrease == True:
                    self.Z -= n
                    command = 'G1 X' + str(self.X) + ' Y' + str(self.Y) + ' Z' + str(self.Z) + F
                    jog_writeline(command)
                    if self.Z1_entry == current_entry:
                        self.Z1.set(str(self.Z))
                    elif self.Z1_2_entry == current_entry:
                         self.Z1_2.set(str(self.Z))
                    elif self.Z1_3_entry == current_entry:
                         self.Z1_3.set(str(self.Z))
                    elif self.Z1_4_entry == current_entry:
                         self.Z1_4.set(str(self.Z))
                    elif self.Z2_entry == current_entry:
                        self.Z2.set(str(self.Z))
                    elif self.Z2_2_entry == current_entry:
                          self.Z2_2.set(str(self.Z))
                    elif self.Z2_3_entry == current_entry:
                          self.Z2_3.set(str(self.Z))
                    elif self.Z2_4_entry == current_entry:
                          self.Z2_4.set(str(self.Z))
                    elif may == 'S3' and self.Z3_entry == current_entry:
                        self.Z3.set(str(self.Z))
                    elif may == 'S3' and self.Z3_2_entry == current_entry:
                        self.Z3_2.set(str(self.Z))
                    elif may == 'S3' and self.Z3_3_entry == current_entry:
                        self.Z3_3.set(str(self.Z))
                    elif may == 'S3' and self.Z3_4_entry == current_entry:
                        self.Z3_4.set(str(self.Z))
                        
                elif self.Zincrease == True:
                    self.Z += n
                    command = 'G1 X' + str(self.X) + ' Y' + str(self.Y) + ' Z' + str(self.Z) + F
                    jog_writeline(command)
                    if self.Z1_entry == current_entry:
                        self.Z1.set(str(self.Z))
                    elif self.Z1_2_entry == current_entry:
                        self.Z1_2.set(str(self.Z))
                    elif self.Z1_3_entry == current_entry:
                        self.Z1_3.set(str(self.Z))
                    elif self.Z1_4_entry == current_entry:
                        self.Z1_4.set(str(self.Z))
                    elif self.Z2_entry == current_entry:
                        self.Z2.set(str(self.Z))
                    elif self.Z2_2_entry == current_entry:
                        self.Z2_2.set(str(self.Z))
                    elif self.Z2_3_entry == current_entry:
                        self.Z2_3.set(str(self.Z))
                    elif self.Z2_4_entry == current_entry:
                        self.Z2_4.set(str(self.Z))
                    elif may == 'S3' and self.Z3_entry == current_entry:
                        self.Z3.set(str(self.Z))
                    elif may == 'S3' and self.Z3_2_entry == current_entry:
                        self.Z3_2.set(str(self.Z))
                    elif may == 'S3' and self.Z3_3_entry == current_entry:
                        self.Z3_3.set(str(self.Z))
                    elif may == 'S3' and self.Z3_4_entry == current_entry:
                        self.Z3_4.set(str(self.Z))

                elif self.Edecrease == True:
                    self.E -= n
                    command = 'G1 X' + str(self.X) + ' Y' + str(self.Y) + ' Z' + str(self.Z) + ' E' + str(self.E) + F
                    jog_writeline(command)
                elif self.Eincrease == True:
                    self.E += n
                    command = 'G1 X' + str(self.X) + ' Y' + str(self.Y) + ' Z' + str(self.Z) + ' E' + str(self.E) + F
                    jog_writeline(command)

                else:
                    self.hold = False
            
            time.sleep(0.02)
            

    def runjog(self):

        self.make_current_pos()   
        global current_entry
        current_entry = None
        top = self.codeManager() #goi ham codeManager de tao ra cac Entry: Y1_entry, Y2_entry...
        top.destroy() #tat ngay khi tao xong cac entry
        #neu cac entry khong duoc tao se bi loi trong ham holdownbutton
        
        self.top = tkinter.Toplevel(self.master)
        self.top.minsize(width=self.screenwidth, height=self.screenheight -60)
        self.top.geometry(('{}x{}+{}+{}').format(self.screenwidth, self.screenheight, 0, 60))
        self.HOMEbutton = tkinter.Button(self.top, bg='orange', text='VỀ GỐC', fg='black', font='Tahoma, 20', command=self.home_xyz)
        self.HOMEbutton.pack()
        self.HOMEbutton.place(height=60, width=150, x=250, y=180)
        self.Xdecrease = tkinter.Button(self.top, bg='gray', text='X-', fg='black', font='Tahoma, 16')
        self.Xdecrease.pack()
        self.Xdecrease.place(height=60, width=100, x=100, y=180)
        self.Xdecrease.bind('<ButtonPress-1>', self.pButtonXdecrease)
        self.Xdecrease.bind('<ButtonRelease-1>', self.rButtonXdecrease)
        self.Xincrease = tkinter.Button(self.top, bg='gray', text='X+', fg='black', font='Tahoma, 16')
        self.Xincrease.pack()
        self.Xincrease.place(height=60, width=100, x=450, y=180)
        self.Xincrease.bind('<ButtonPress-1>', self.pButtonXincrease)
        self.Xincrease.bind('<ButtonRelease-1>', self.rButtonXincrease)
        self.Ydecrease = tkinter.Button(self.top, bg='pink', text='Y-', fg='black', font='Tahoma, 16')
        self.Ydecrease.pack()
        self.Ydecrease.place(height=50, width=100, x=270, y=100)
        self.Ydecrease.bind('<ButtonPress-1>', self.pButtonYdecrease)
        self.Ydecrease.bind('<ButtonRelease-1>', self.rButtonYdecrease)
        self.Yincrease = tkinter.Button(self.top, bg='pink', text='Y+', fg='black', font='Tahoma, 16')
        self.Yincrease.pack()
        self.Yincrease.place(height=60, width=100, x=270, y=260)
        self.Yincrease.bind('<ButtonPress-1>', self.pButtonYincrease)
        self.Yincrease.bind('<ButtonRelease-1>', self.rButtonYincrease)
        self.Zdecrease = tkinter.Button(self.top, bg='cyan', text='Z-', fg='black', font='Tahoma, 16')
        self.Zdecrease.pack()
        self.Zdecrease.place(height=60, width=100, x=450, y=100)
        self.Zdecrease.bind('<ButtonPress-1>', self.pButtonZdecrease)
        self.Zdecrease.bind('<ButtonRelease-1>', self.rButtonZdecrease)
        self.Zincrease = tkinter.Button(self.top, bg='cyan', text='Z+', fg='black', font='Tahoma, 16')
        self.Zincrease.pack()
        self.Zincrease.place(height=60, width=100, x=450, y=260)
        self.Zincrease.bind('<ButtonPress-1>', self.pButtonZincrease)
        self.Zincrease.bind('<ButtonRelease-1>', self.rButtonZincrease)

        self.Edecrease = tkinter.Button(self.top, bg='lightgreen', text='E-', fg='black', font='Tahoma, 16')
        self.Edecrease.pack()
        self.Edecrease.place(height=60, width=100, x=600, y=100)
        self.Edecrease.bind('<ButtonPress-1>', self.pButtonEdecrease)
        self.Edecrease.bind('<ButtonRelease-1>', self.rButtonEdecrease)
        self.Eincrease = tkinter.Button(self.top, bg='lightgreen', text='E+', fg='black', font='Tahoma, 16')
        self.Eincrease.pack()
        self.Eincrease.place(height=60, width=100, x=600, y=260)
        self.Eincrease.bind('<ButtonPress-1>', self.pButtonEincrease)
        self.Eincrease.bind('<ButtonRelease-1>', self.rButtonEincrease)
        
        if may == 'S3':
            self.B = tkinter.Button(self.top, bg='blue4', text='Khóa/mở khóa trục E', fg='white', font='Tahoma, 16',
                                    command=self.khoa_truc_E)
            self.B.pack()
            self.B.place(height=60, width=250, x=100, y=350)
        
        self.B = tkinter.Button(self.top, bg='blue4', text='Thoát', fg='white', font='Tahoma, 16', command=self.top.destroy)
        self.B.pack()
        self.B.place(height=60, width=100, x=450, y=350)

    def move_canvas(self, text):
        if text == 'cv1_up':
            self.cv1.move('all', 0, 100)
        elif text == 'cv1_down':
            self.cv1.move('all', 0, -100)
        elif text == 'cv2_up':
            self.cv2.move('all', 0, 100)
        elif text == 'cv2_down':
            self.cv2.move('all', 0, -100)
        elif text == 'p2cv1_up':
            self.p2cv1.move('all', 0, 100)
        elif text == 'p2cv1_down':
            self.p2cv1.move('all', 0, -100)
        elif text == 'p2cv2_up':
            self.p2cv2.move('all', 0, 100)
        elif text == 'p2cv2_down':
            self.p2cv2.move('all', 0, -100)
        elif text == 'cv4_2_up':
            self.cv4_2.move('all', 0, 100)
        elif text == 'cv4_2_down':
            self.cv4_2.move('all', 0, -100)


    def make_new_file(self, top):
        'tao file code tu du lieu nhap vao cac entry'
        Xt = float(self.X_tim.get()) #tim khoa nguoi dung nhap
        Y1 = float(self.Y1.get())
        Z1 = float(self.Z1.get())
        Z1_2 = float(self.Z1_2.get())
        Z1_3 = float(self.Z1_3.get())
        Z1_4 = float(self.Z1_4.get())
        Y2 = float(self.Y2.get())
        Z2 = float(self.Z2.get())
        Z2_2 = float(self.Z2_2.get())
        Z2_3 = float(self.Z2_3.get())
        Z2_4 = float(self.Z2_4.get())
        Y3 = float(self.Y3.get())
        Z3 = float(self.Z3.get())
        Z3_2 = float(self.Z3_2.get())
        Z3_3 = float(self.Z3_3.get())
        Z3_4 = float(self.Z3_4.get())
        # if Z1 != 0.0 and Z1 < 12.0: Z1 = 12.0 # dieu chinh de neu nhap sai may khong vuot qua hanh trinh
        # if Z1_2 != 0.0 and Z1_2 < Z1: Z1_2 = Z1
        # if Z2 != 0.0 and Z2 < 12.0: Z2 = 12.0
        # if Z2_2 != 0.0 and Z2_2 < Z2: Z2_2 = Z2
        # if Z3 != 0.0 and Z3 < 12.0: Z3 = 12.0
        # if Z3_2 != 0.0 and Z3_2 < Z3: Z3_2 = Z3
        if may == 'S3': z_speed = ' F2000 \n'
        else: z_speed = ' F1000 \n'

        name = ''
        comment = '' #bien luu giu dong chu thich trong code, vd: TIM_LOP1, TIM_LOP2, VIT1_LOP1...
        try:
            filename = True
            new_filename = self.box.get(1.0, END)
            new_filename = new_filename[0: len(new_filename) - 1] #bo ky tu \n cuoi cung
            print('new_filename: ', new_filename)
            list_files = os.listdir(self.path + self.dirname)

            if new_filename == '':
                messagebox.showinfo("Lỗi!", "CHƯA NHẬP TÊN HOẶC TRÙNG TÊN!")
                filename = False  # khong tao FILE co ten nay
                self.top.focus_set()  # dat cs toplevel len tren
            else:
                for file in list_files:
                    file = file.replace('.gcode', '')
                    print('old_filename: ', file)
                    if new_filename == file:
                        messagebox.showinfo("Lỗi!", "CHƯA NHẬP TÊN HOẶC TRÙNG TÊN!")
                        filename = False #khong tao FILE co ten nay
                        self.top.focus_set() #dat cs toplevel len tren
                    
            if filename == True:
                path = self.path + self.dirname + '/'
                #print(path) # duong dan thu muc (phu kien) dang duoc chon
                new_code_file = path + new_filename + '.gcode' #dat ten file
                f = open(new_code_file, 'w+')  # tao file
                f.close()
                f = open(new_code_file, 'r+', encoding='utf-8')
                f.write('; CREATED BY NGUYEN XUAN TOAN 0796451985\nM120\nG28\nM121\nG21 G90 M82\nG92 E0\n')
                if may == 'S3':
                    f.write('M35 E1\n')
                f.write('M106\n')
                #MAT 1: sua nd file mau va ghi vao newfile
                items = self.cv1b.find_all() # doi tuong co trong canvas
                if items != () and float(self.Y1.get()) >= 12.0 and float(self.Y1.get()) < 240.0 and float(self.Z1.get()) >= 12.0 and float(self.Z1.get()) < 185:
                    # Y nam trong khoang 12-240 thi khong va vao thuoc tua
                    # Z nam trong khoang 12-185 thi khong dam xuong mat thuoc va Z-10 lon hon 0
                    path_file_mau1 = self.path2 + self.mau1 #duong dan den file mau mat 1            
                    file_mau1 = open(path_file_mau1, 'r') #mo file
                    nd_file = file_mau1.readlines()
                    file_mau1.close()
                    hole = [] #list toa do cua 1 lo khoan cua mat 1
                    for nd_dong_i in nd_file:
                        if nd_dong_i == '\n': #neu la dong trong
                        # truong hop mat 1 co nhieu lo, copy het 1 doan trong file mau se thuc hien code nay (code1)
                            # chay lop 2 neu co
                            if Z1_2 > Z1 and Z1_2 < 185 and hole != []: #neu mat 1 can chay 2 lop va da chay xong lop 1
                                f.write(';LOP 2\n')
                                f.write('G1 Z' + str(Z1_2-5) + z_speed)
                                f.write('G1 Z' + str(Z1_2+5) + ' F200 \n')
                                for line in hole:
                                    f.write(line) #ghi code luu trong list vao file

                            # chay lop 3 neu co
                            if Z1_3 > Z1_2 and Z1_3 < 185:  # neu mat 1 can chay 2 lop va da chay xong lop 1
                                f.write(';LOP 3\n')
                                f.write('G1 Z' + str(Z1_3 - 5) + z_speed)
                                f.write('G1 Z' + str(Z1_3 + 5) + ' F200 \n')
                                for line in hole:
                                    f.write(line)  # ghi code luu trong list vao file

                            # chay lop 4 neu co
                            if Z1_4 > Z1_3 and Z1_4 < 185:  # neu mat 1 can chay 2 lop va da chay xong lop 1
                                f.write(';LOP 4\n')
                                f.write('G1 Z' + str(Z1_4 - 5) + z_speed)
                                f.write('G1 Z' + str(Z1_4 + 5) + ' F200 \n')
                                for line in hole:
                                    f.write(line)  # ghi code luu trong list vao file

                            hole.clear() #xoa list
                            f.write('G1 Z' + str(Z1-10) + z_speed)
                        elif ';' in nd_dong_i:
                            comment = nd_dong_i
                            f.write(comment) #copy dong chu thich vao newfile
                        else:
                            dong_i = nd_dong_i.split()
                            if dong_i[0] != name: #bat dau 1 lo khoan moi                            

                                name = dong_i[0]
                                feed = max_feed
                            else:
                                feed = ' F250 \n'
                            text = dong_i[1]
                            text_ed = text.replace('X', '')
                            X = float(text_ed) #toa do X trong file mau
                            X_new = X - 160.00 + Xt #toa do se ghi vao newfile
                            
                            text = dong_i[2]
                            text_ed = text.replace('Y', '')
                            Y = float(text_ed)
                            Y_new = Y + Y1 #toa do se ghi vao newfile
                            
                            #ghi toa do X_new, Y_new vao newfile
                            gcode = 'G1 X' + str(format(X_new, '.4f')) + ' Y' + str(format(Y_new, '.4f')) + feed
                            f.write(gcode)
                            hole.append(gcode)
                        
                            if feed == max_feed: #vua chay jog den vi tri khoan moi
                                f.write('G1 Z' + str(Z1-10) + z_speed)
                                f.write('G1 Z' + str(Z1+10) + ' F200 \n')

                    # neu mat 1 chi co 1 lo thi copy den het file mau code1 van chua duoc thuc hien
                    # chua tao duoc lop 2, 3, 4
                    # can thuc hien code nay (code2)
                    if Z1_2 > Z1 and Z1_2 < 185 and hole != []: #neu mat 1 can chay 2 lop va da chay xong lop 1
                        # chay lop 2 neu co
                        f.write(';LOP 2\n')
                        f.write('G1 Z' + str(Z1_2-5) + z_speed)
                        f.write('G1 Z' + str(Z1_2+5) + ' F200 \n')
                        for line in hole:
                            f.write(line) #ghi code luu trong list vao file

                        # chay lop 3 neu co
                        if Z1_3 > Z1_2 and Z1_3 < 185:  # neu mat 1 can chay 2 lop va da chay xong lop 1
                            f.write(';LOP 3\n')
                            f.write('G1 Z' + str(Z1_3 - 5) + z_speed)
                            f.write('G1 Z' + str(Z1_3 + 5) + ' F200 \n')
                            for line in hole:
                                f.write(line)  # ghi code luu trong list vao file

                        # chay lop 4 neu co
                        if Z1_4 > Z1_3 and Z1_4 < 185:  # neu mat 1 can chay 2 lop va da chay xong lop 1
                            f.write(';LOP 4\n')
                            f.write('G1 Z' + str(Z1_4 - 5) + z_speed)
                            f.write('G1 Z' + str(Z1_4 + 5) + ' F200 \n')
                            for line in hole:
                                f.write(line)  # ghi code luu trong list vao file
                        hole.clear() #xoa list
                    if may == 'S3':
                        f.write('M35 E0\n') # xong mat 1
                        
                    # file_mau1.close()

                #MAT 2: sua nd file mau va ghi vao newfile
                items = self.cv2b.find_all() # doi tuong co trong canvas
                if items != () and float(self.Y2.get()) >= 12.0 and float(self.Y2.get()) < 140.0 and float(self.Z2.get()) >= 12.0 and float(self.Z2.get()) <= 275.0:
                    # Y nam trong khoang 12-140 thi khong va vao thuoc tua
                    # Z nam trong khoang 12-275 thi khong dam xuong vuot qua hanh trinh
                    #vua phay xong mat 1, nhac dao len de chuan bi phay mat 2. dua vao z1 de tinh khoang nhac dao len
                    Z_safe = Z1 - 50.0 # nhac dao len 50, di chuyen den vi tri khoan mat 2, quay lat mat
                    if Z_safe < 2.0: Z_safe = 2.0
                    f.write('; PHAY MAT 2 \n')
                    f.write('G1 Z' + str(Z_safe) + z_speed)
                    f.write('G1 X100 Y50.0' + max_feed)
                    f.write('G1 E90.0' + max_feed)
                    if may == 'S3':
                        f.write('M35 E1\n')
                    #tiep tuc copy tu file mau
                    path_file_mau2 = self.path2 + self.mau2 #duong dan den file mau mat 1
                    file_mau2 = open(path_file_mau2, 'r') #mo file
                    nd_file = file_mau2.readlines()
                    file_mau2.close()
                    #print(nd_file)
                    hole = [] #list toa do cua 1 lo khoan cua mat 2
                    for nd_dong_i in nd_file:
                        # code3
                        if nd_dong_i == '\n': #dong trong tuc la vua copy xong 1 lo(cua 1 lop)
                            # neu vua copy xong 1 lo cua lop 2 thi kiem tra xem co tao lop 3,4 khong
                            # lop 3, 4 toa do giong lop 2 (khac lop 1)
                            if 'LOP2' in name and Z2_3 > Z2_2 and Z2_3 <= 275: # tao lop 3
                                f.write('; LOP 3\n')
                                f.write('G1 Z' + str(Z2_3 - 5) + z_speed)
                                f.write('G1 Z' + str(Z2_3 + 5) + ' F200 \n')
                                for line in hole:
                                    f.write(line)
                            if 'LOP2' in name and Z2_4 > Z2_3 and Z2_4 <= 275:  # tao lop 4
                                f.write('; LOP 4\n')
                                f.write('G1 Z' + str(Z2_4 - 5) + z_speed)
                                f.write('G1 Z' + str(Z2_4 + 5) + ' F200 \n')
                                for line in hole:
                                    f.write(line)
                            hole.clear() #xoa list

                        elif ';' in nd_dong_i:
                            comment = nd_dong_i
                            f.write(comment) #copy dong chu thich vao newfile
                        else:
                            dong_i = nd_dong_i.split()
                            if dong_i[0] != name: #bat dau 1 lo khoan moi
                                #if name == 'TIM' or name == 'VIT1' or name == 'VIT2' or name == 'CU_KHOA':
                                name = dong_i[0]
                                feed = max_feed
                                if 'LOP2' not in name and 'TIM_LOP1' not in name:
                                    f.write('G1 Z' + str(Z2-10) + z_speed)
                            
                            else:
                                feed = ' F250 \n'
                            text = dong_i[1]
                            text_ed = text.replace('X', '')
                            X = float(text_ed) #toa do X trong file mau
                            X_new = X - 160.00 + Xt #toa do se ghi vao newfile
                            
                            text = dong_i[2]
                            text_ed = text.replace('Y', '')
                            Y = float(text_ed)
                            Y_new = Y + Y2 #toa do se ghi vao newfile
                            
                            #ghi toa do X_new, Y_new vao newfile dong thoi them vao list toa_do
                            if ('LOP1' in name and Z2 > 0) or ('LOP2' in name and Z2_2 > Z2):
                                gcode = 'G1 X' + str(format(X_new, '.4f')) + ' Y' + str(format(Y_new, '.4f')) + feed
                                f.write(gcode)
                                hole.append(gcode)
                            if feed == max_feed: #vua chay jog den vi tri khoan moi
                                if 'LOP1' in name and Z2 > 0.0:
                                    f.write('G1 Z' + str(Z2-10) + z_speed)
                                    f.write('G1 Z' + str(Z2+10) + ' F200 \n')
                                
                                elif 'LOP2' in name and Z2_2 > 0.0:
                                    f.write('G1 Z' + str(Z2_2-10) + z_speed)
                                    f.write('G1 Z' + str(Z2_2+5) + ' F200 \n')
                        # copy xong file mau

                    # neu trong file mau chi tao lop 1 hoac trong file mau mat 2 chi co 1 lo
                    # doan ma trong code1 (if nd_dong_i == '\n') se khong duoc thuc hien
                    # tao lop 3,4 bang doan ma nay
                    # neu da thuc hien doan ma trong code3 (if nd_dong_i == '\n') thi hole == [] nen ma sau se khong duoc thuc hien
                    if Z2_3 > Z2_2 and Z2_3 <= 275 and hole !=[]:  # tao lop 3
                        f.write('; LOP 3\n')
                        f.write('G1 Z' + str(Z2_3 - 5) + z_speed)
                        f.write('G1 Z' + str(Z2_3 + 5) + ' F200 \n')
                        for line in hole:
                            f.write(line)
                    if Z2_4 > Z2_3 and Z2_4 <= 275 and hole !=[]:  # tao lop 4
                        f.write('; LOP 4\n')
                        f.write('G1 Z' + str(Z2_4 - 5) + z_speed)
                        f.write('G1 Z' + str(Z2_4 + 5) + ' F200 \n')
                        for line in hole:
                            f.write(line)
                    hole.clear()  # xoa list

                    if may == 'S3':
                        f.write('M35 E0\n') # xong mat 2

                    # MAT 3: sua nd file mau va ghi vao newfile
                    if may == 'S3' and float(self.Y3.get()) >= 12.0 and float(self.Z3.get()) >= 12.0:
                        f.write('; PHAY MAT 3 \n')
                        f.write('G1 Z' + str(Z_safe) + z_speed)
                        f.write('G1 E-90.0 F2000 \n')
                        f.write('M35 E1\n')
                        #copy lan 2 tu file mau
                        hole = [] #list toa do cua 1 lo khoan cua mat 2
                        for nd_dong_i in nd_file:
                            if nd_dong_i == '\n':  # dong trong tuc la vua copy xong 1 lo(cua 1 lop)
                                # neu vua copy xong 1 lo cua lop 2 thi kiem tra xem co tao lop 3,4 khong
                                # lop 3, 4 toa do giong lop 2 (khac lop 1)
                                if 'LOP2' in name and Z3_3 > Z3_2 and Z3_3 <= 275:  # tao lop 3
                                    f.write('; LOP 3\n')
                                    f.write('G1 Z' + str(Z3_3 - 5) + z_speed)
                                    f.write('G1 Z' + str(Z3_3 + 5) + ' F200 \n')
                                    for line in hole:
                                        f.write(line)
                                if 'LOP2' in name and Z3_4 > Z3_3 and Z3_4 <= 275:  # tao lop 4
                                    f.write('; LOP 4\n')
                                    f.write('G1 Z' + str(Z3_4 - 5) + z_speed)
                                    f.write('G1 Z' + str(Z3_4 + 5) + ' F200 \n')
                                    for line in hole:
                                        f.write(line)
                                hole.clear()  # xoa list
                            elif ';' in nd_dong_i:
                                comment = nd_dong_i
                                f.write(comment)  # copy dong chu thich vao newfile
                            else:
                                dong_i = nd_dong_i.split()
                                if dong_i[0] != name:  # bat dau 1 lo khoan moi
                                    # if name == 'TIM' or name == 'VIT1' or name == 'VIT2' or name == 'CU_KHOA':
                                    name = dong_i[0]
                                    feed = max_feed
                                    if 'LOP2' not in name and 'TIM_LOP1' not in name:
                                        f.write('G1 Z' + str(Z3 - 10) + z_speed)

                                else:
                                    feed = ' F250 \n'
                                text = dong_i[1]
                                text_ed = text.replace('X', '')
                                X = float(text_ed)  # toa do X trong file mau
                                X_new = X - 160.00 + Xt  # toa do se ghi vao newfile

                                text = dong_i[2]
                                text_ed = text.replace('Y', '')
                                Y = float(text_ed)
                                Y_new = Y + Y3  # toa do se ghi vao newfile

                                # ghi toa do X_new, Y_new vao newfile dong thoi them vao list toa_do
                                if ('LOP1' in name and Z3 >= 12.0) or ('LOP2' in name and Z3 >= 12.0 and Z3_2 >= 12.0):
                                    gcode = 'G1 X' + str(format(X_new, '.4f')) + ' Y' + str(format(Y_new, '.4f')) + feed
                                    f.write(gcode)
                                    hole.append(gcode)

                                if feed == max_feed:  # vua chay jog den vi tri khoan moi
                                    if 'LOP1' in name and Z3 >= 12.0:
                                        f.write('G1 Z' + str(Z3 - 10) + z_speed)
                                        f.write('G1 Z' + str(Z3 + 10) + ' F200 \n')


                                    elif 'LOP2' in name and Z3_2 > 0.0:
                                        f.write('G1 Z' + str(Z3_2 - 10) + z_speed)
                                        f.write('G1 Z' + str(Z3_2 + 5) + ' F200 \n')
                        # neu da thuc hien doan ma trong code3 (if nd_dong_i == '\n') thi hole == [] nen ma sau se khong duoc thuc hien
                        if Z3_3 > Z2_2 and Z3_3 <= 275 and hole != []:  # tao lop 3
                            f.write('; LOP 3\n')
                            f.write('G1 Z' + str(Z3_3 - 5) + z_speed)
                            f.write('G1 Z' + str(Z3_3 + 5) + ' F200 \n')
                            for line in hole:
                                f.write(line)
                        if Z3_4 > Z2_3 and Z3_4 <= 275 and hole != []:  # tao lop 4
                            f.write('; LOP 4\n')
                            f.write('G1 Z' + str(Z3_4 - 5) + z_speed)
                            f.write('G1 Z' + str(Z3_4 + 5) + ' F200 \n')
                            for line in hole:
                                f.write(line)
                        hole.clear()  # xoa list
                        f.write('M35 E0\n')  # xong mat 3

                    # file_mau2.close()
                f.write('M107\nG1 Z5.0' + z_speed)
                f.write('G1 X5.0 Y5.0' + max_feed)
                f.write('G1 E0.0' + max_feed)
                f.close() #file vua tao
                loai_nhom.append(new_filename)            
                self.create_file_menu(self.cv2, self.dirname) #tao menu trong page1
                self.create_file_menu(self.p2cv2, self.dirname) #menu trong page2
                messagebox.showinfo('', 'Chương trình đã được tạo\ntrong thư mục ' + self.dirname)
                self.top.destroy()
                top.focus_set()
        except:
            messagebox.showinfo("Lỗi 1!", "Chưa đủ thông số hoặc chưa chọn mẫu!")
            
            

    # def set_filename(self, top):
    #     'dat ten cho newfile bang vkeyboard'
    #     items_1 = self.cv1b.find_all() # doi tuong co trong canvas
    #     items_2 = self.cv2b.find_all() # doi tuong co trong canvas
    #     if items_1 != () or items_2 != ():
    #         self.new_file_folder('newFile') #ham new_file_folder tao ra toplevel, hop thoai ban phim ao de nhap ten
    #         #print('top:', top)
    #         b = Button(self.top, text='    Tiếp tục    ', font='Tahoma, 16', command=lambda: self.make_new_file(top))
    #         b.grid(row=9,column=0)
    #         Button(self.top, text='    Hủy    ', font='Tahoma, 16', command=self.top.destroy).grid(row=9,column=1)
    #     else:
    #         messagebox.showinfo("Lỗi 2!", "Chưa đủ thông số hoặc chưa chọn mẫu!")
    #         top.focus_set()


    def select_entry(self, event):
        global current_entry
        current_entry = event.widget #
        # print('current_entry: ', current_entry)
        

    def draw(self, canvas):
        'list index out of range'
        # print(self.mau_pk)
        f = open(self.path2 + self.mau_pk, mode='r', encoding='utf-8')
        ndfile = f.readlines()
        f.close()
        global tag # text dau tien trong 1 dong
        tag = ''
        points = []
        Y_m1 = 0.0 #bien luu gia tri nn, ln cua toa do Y - dung de ve 2 duong thang mat 1
        ymax = 0.0
        xTim_items = [] # toa do x cua cac duong giong kich thuoc
        # canvas.delete('all')

        #ve ra cac polygon tu nd file
        for nd_dong_i in ndfile:
            dong_i = nd_dong_i.split()
            if dong_i != [] and ';' not in dong_i[0]: #neu khong phai dong chu thic
                if dong_i[0] != tag: #het toa do 1 hinh, chuyen sang hinh khac                    
                    
                    if points != [] :
                        #canvas.create_text(50, 50, ancho='nw', text='LOAIKHOA', font="Tahoma, 14")
                        canvas.create_polygon(points, outline="gray15", width=8, fill="gray15", tags=tag)
                        # ve trong cv4
                        if '(M1)' in self.mau_pk:
                            self.cv4.create_polygon(points, outline="gray15", width=8, fill="gray15", tags='M1')
                        elif '(M2)' in self.mau_pk and 'LOP1' in tag:
                            if 'CU_KHOA' in tag:
                                self.cv4.create_polygon(points, outline="gray15", width=8, fill="gray15", tags='CU_KHOA')
                            else:
                                self.cv4.create_polygon(points, outline="gray15", width=8, fill="gray15", tags='M2')

                        points.clear() #xoa list                       
                                               
                    tag = dong_i[0] #thay gia tri cua tag
                    
                else: #them toa do vao polygon
                    text = dong_i[1]
                    text_ed = text.replace('X', '')
                    X = float(text_ed)
                    points.append(X)
                    #print('X = ', X)
                    
                    text = dong_i[2]
                    text_ed = text.replace('Y', '')
                    Y = float(text_ed)
                    points.append(Y)
                    if Y > ymax: ymax = Y
                    #print('Y = ', Y)

        if points != []:
            canvas.create_polygon(points, outline="gray15", width=8, fill="gray15", tags=tag) # ve hinh cuoi cung
            # ve trong cv4
            if '(M1)' in self.mau_pk:
                self.cv4.create_polygon(points, outline="gray15", width=8, fill="gray15", tags='M1')
            elif '(M2)' in self.mau_pk and 'LOP1' in tag:
                self.cv4.create_polygon(points, outline="gray15", width=8, fill="gray15", tags='M2')

        # canvas.scale('all', 0, 0, 2.0, 2.0) #phong to len 2.0 lan
        coords = canvas.bbox('all') #toa do cua hcn bao tat ca cac doi tuong trong canvas
        #print(coords)

        # ve 2 doan thang dai 300 tuong trung cho mat 1
        if canvas == self.cv1b and coords != None:
            #ghi ten pk
            xt = 0  # toa do se ghi ten phu kien
            yt = coords[1]-20  # toa do se ghi ten phu kien
            ten_pk = self.mau_pk[0: len(self.mau_pk) - 4 - 5]
            canvas.create_text(xt, yt, text=ten_pk, font='Tahoma, 12', anchor='w')
            canvas.create_text(-80, (coords[1]+coords[3])/2, text='Mặt 1', font='Tahoma, 11', anchor='w')
            mat1 = canvas.create_rectangle(-500, coords[1] - 10, 500, coords[3] + 10, outline = 'white', fill='gray70')
            canvas.lower(mat1)
        elif canvas == self.cv2b and coords != None:
            ten_pk = self.mau_pk[0: len(self.mau_pk) - 4 - 5]
            canvas.create_text(-80, (coords[1] + coords[3]) / 2, text='Mặt 2', font='Tahoma, 11', anchor='w')
            canvas.create_text(-80, (coords[1] + coords[3]) / 2 + 45, text=ten_pk, font='Tahoma, 11', anchor='w')
            mat2 = canvas.create_rectangle(-500, coords[1] - 20, 500, coords[3] + 20, outline = 'white', fill='gray55')
            canvas.lower(mat2)

        canvas_width = self.screenwidth * 2 / 3 - 10 #kikch thuoc canvas
        # dx = canvas_width/2 - (coords[0]+coords[2])/2 #di chuyen theo X
        #dy = 55 - (coords[1]+coords[3])/2# di chuyen theo Y
        if canvas == self.cv1b and coords != None:
            canvas.move('all', 100, -coords[3] - 10 + 90)
            mat1 = self.cv4.find_withtag('M1')
            coords = self.cv4.bbox(mat1)
            if coords != None:
                coords = [coords[0]+4, coords[1], coords[2]-4, coords[3]] # bu chieu rong net ve
                xTim_items = [coords[0], 160.00, coords[2]]
                xTim_items.sort()
                self.cv4.create_line(coords[0], coords[3]+10, coords[0], coords[3]+30, tag='M1')
                self.cv4.create_line(160, coords[3] + 10, 160, coords[3] + 100, tag='M1')
                self.cv4.create_line(coords[2], coords[3] + 10, coords[2], coords[3] + 30, tag='M1')
                # self.cv4.create_text((coords[0]+160)/2, coords[3]+20, text=160-coords[0], font='Tahoma, 12', tag='M1')
                # self.cv4.create_text((coords[2]+160)/2, coords[3]+20, text=coords[2]-160, font='Tahoma, 12', tag='M1')

                n = len(xTim_items)
                while n > 1:
                    # print(tim)
                    kichThuoc = xTim_items[n-1] - xTim_items[n-2]
                    # print(kichThuoc)
                    self.cv4.create_text((xTim_items[n-1] + xTim_items[n-2])/2, coords[3]+20, text=kichThuoc, font='Tahoma, 11', tag='M1')
                    n -= 1

            self.cv4.move('M1', 25, 80)
            self.cv4.scale('M1', 0, 0, 1.8, 1.8)  # phong to len 2.0 lan
        elif canvas == self.cv2b and coords != None:
            mat2 = self.cv4.find_withtag('M2') + self.cv4.find_withtag('CU_KHOA')
            for item in mat2:
                # print(item)
                # coords_item = self.cv4.coords(item)
                if 'CU_KHOA' in self.cv4.gettags(item):
                    toa_do = self.cv4.coords(item)
                    ymin = 0
                    n=1
                    while n < len(toa_do):
                        if toa_do[n] < ymin:
                            ymin = toa_do[n]
                        n += 2
                    # print('ymin=', ymin)
                    x = toa_do[toa_do.index(ymin)-1] # toa do tim x cua cu khoa
                else:
                    coords_item = self.cv4.bbox(item)
                    # print(coords_item)
                    x = (coords_item[0] + coords_item[2])/2
                xTim_items.append(x)
                # self.cv4.create_line(x, ymax + 10, x, ymax + 30, tag='kich_thuoc')
            xTim_items.sort()
            # print(xTim_items)
            if len(xTim_items) >= 2:
                for x in xTim_items:
                    self.cv4.create_line(x, ymax + 10, x, ymax + 30, tag='kich_thuoc')
                n = len(xTim_items)
                while n > 1:
                    # print(tim)
                    kichThuoc = xTim_items[n-1] - xTim_items[n-2]
                    # print(kichThuoc)
                    self.cv4.create_text((xTim_items[n-1] + xTim_items[n-2])/2, ymax + 20, text=kichThuoc, font='Tahoma, 11', tag='kich_thuoc')
                    n -= 1

            canvas.move('all', 100, -coords[1]+20)
            self.cv4.move('M2', 25, 150)
            self.cv4.move('CU_KHOA', 25, 150)
            self.cv4.move('kich_thuoc', 25, 150)
            self.cv4.scale('M2', 0, 0, 1.8, 1.8)  # phong to len 2.0 lan
            self.cv4.scale('CU_KHOA', 0, 0, 1.8, 1.8)  # phong to len 2.0 lan
            self.cv4.scale('kich_thuoc', 0, 0, 1.8, 1.8)  # phong to len 2.0 lan

        ten_pk = self.mau_pk[0: len(self.mau_pk) - 4 - 5]
        self.cv4.create_text(80,50, text=ten_pk, font='Tahoma, 12', anchor='w')
        # canvas.create_text(-80, (coords[1] + coords[3]) / 2, text='Mặt 1', font='Tahoma, 11', anchor='w')
        # mat1 = canvas.create_rectangle(-500, coords[1] - 10, 500, coords[3] + 10, outline='white', fill='gray70')
        # canvas.lower(mat1)
        #
        # canvas.create_text(-80, (coords[1] + coords[3]) / 2, text='Mặt 2', font='Tahoma, 11', anchor='w')
        # canvas.create_text(-80, (coords[1] + coords[3]) / 2 + 45, text=ten_pk, font='Tahoma, 11', anchor='w')
        # mat2 = canvas.create_rectangle(-500, coords[1] - 20, 500, coords[3] + 20, outline='white', fill='gray55')
        # canvas.lower(mat2)


    def back_in_cv1b(self):
        global STT
        try:
            soLuong_mau = len(self.mau_pk_m1)
            #print(soLuong_mau)            
            self.mau_pk = self.mau_pk_m1[STT]
            self.cv1b.delete('all') #xoa truoc khi ve
            self.cv2b.delete('all')
            self.cv4.delete('all')
            self.draw(self.cv1b)
            self.mau1 = self.mau_pk # file mau mat 1
            STT += 1

            #xac dinh file mau mat 2 va ve vao cv2b
            ten_pk = self.mau_pk[0: len(self.mau_pk) - 9]
            #print('ten pk: ', ten_pk)
            for pk in self.mau_pk_m2:
                if ten_pk == pk[0: len(pk) - 9]:
                    self.mau_pk = pk
                    self.draw(self.cv2b)
                    self.mau2 = self.mau_pk  # file mau mat 2
                    break

            #tao vong lap
            if STT == len(self.mau_pk_m1):
                STT = 0
        except:
            print('sl mau = ',soLuong_mau, ' STT = ', STT)
            STT = 0
            self.back_in_cv1b()

    def next_in_cv1b(self):
        global STT
        try:
            soLuong_mau = len(self.mau_pk_m1)
            # print(soLuong_mau)
            self.mau_pk = self.mau_pk_m1[STT]
            self.cv1b.delete('all')  # xoa truoc khi ve
            self.cv2b.delete('all')
            self.cv4.delete('all')
            self.draw(self.cv1b)
            self.mau1 = self.mau_pk  # file mau mat 1
            STT -= 1

            # xac dinh file mau mat 2 va ve vao cv2b
            ten_pk = self.mau_pk[0: len(self.mau_pk) - 9]
            # print('ten pk: ', ten_pk)
            for pk in self.mau_pk_m2:
                if ten_pk == pk[0: len(pk) - 9]:
                    self.mau_pk = pk
                    self.draw(self.cv2b)
                    self.mau2 = self.mau_pk  # file mau mat 2
                    break
            # tao vong lap
            if STT == -1:
                STT = len(self.mau_pk_m1)-1
        except:
            STT = len(self.mau_pk_m1) - 1
            self.next_in_cv1b()


    def insert_entry_delta_y(self, text):
        if text == '+':
            var = float(self.delta_y.get())
            var += 0.5
            self.delta_y.set(str(var))
        elif text == '-':
            var = float(self.delta_y.get())
            var -= 0.5
            self.delta_y.set(str(var))

    def khoa_truc_E(self):
        global e_lock
        if e_lock == False:
            #print('M35 E1')
            ser.write(('M35 E1\\').encode())
            e_lock = True
        elif e_lock == True:
            #print('M35 E0')
            ser.write(('M35 E0\\').encode())
            e_lock = False

    def vkeyboard2_selected(self, key):
        try:
            # print(key)
            text = current_entry.get()
            if key == 'C':  # xoa tu 0, END
                current_entry.delete(0, END)
                current_entry.insert(0, '0.0')
            elif key == '.': #neu chua co dau '.' thi moi them vao
                if text != '' and '.' not in text:
                    current_entry.insert(END, key)
            elif key == '-':
                if '-' in text:
                    current_entry.delete(0, 1)
                    # current_entry.insert(0, text)
                elif text == '0.0':
                    current_entry.delete(0, END)
                    current_entry.insert(END, key)
                else:
                    current_entry.insert(0, key)
            else:
                if text == '0.0':
                    current_entry.delete(0, END)
                current_entry.insert(END, key)
        except: # khong chon vao entry
            print('not selected entry!')

    def chon_mau_pk(self, event):
        items = self.cv4_2.find_overlapping(event.x - 1, event.y - 1, event.x + 1, event.y + 1)
        for item in items:
            tag = self.cv4_2.gettags(item)
            # print('tag:', tag)
            if tag != () and tag[0] != 'current':
                self.mau_pk = tag[0].replace('^', ' ')
                # print (mau_pk)
                if self.mau_pk in self.mau_pk_m1:
                    # tao hieu ung danh dau menu dang duoc chon
                    self.cv4_2.itemconfigure('all', width=0)
                    self.cv4_2.itemconfigure(item, width=2, outline='blue')

                    self.cv1b.delete('all')  # xoa truoc khi ve
                    self.cv2b.delete('all')
                    self.cv4.delete('all')
                    self.draw(self.cv1b)
                    self.mau1 = self.mau_pk  # file mau mat 1 de tao code

                    # xac dinh file mau mat 2 va ve vao cv2b
                    ten_pk = self.mau_pk[0: len(self.mau_pk) - 9]
                    # print('ten pk: ', ten_pk)
                    for pk in self.mau_pk_m2:
                        if ten_pk == pk[0: len(pk) - 9]:
                            self.mau_pk = pk
                            self.draw(self.cv2b)
                            self.mau2 = self.mau_pk  # file mau mat 2 de tao code
                            break
                        else:
                            self.mau2 = '' # de ham xoa_mau_pk khong xoa nham file cua lan chon truoc


    def xoa_mau_pk(self, sketch, top):
        top.destroy()
        file_mau_mat_1 = self.path2 + self.mau1
        os.remove(file_mau_mat_1)
        if self.mau2 != '':
            file_mau_mat_2 = self.path2 + self.mau2
            os.remove(file_mau_mat_2)
        # dong cs roi mo lai de cap nhat menu
        sketch.destroy()
        self.draw_detail(top)


    def hoi_xoa_mau_pk(self, sketch):
        # dialog_title = 'Tiếp tục xóa?'
        # dialog_text = 'Xóa phụ kiện   ' + self.mau_pk + '   khỏi bộ nhớ?'
        # answer = messagebox.askquestion(dialog_title, dialog_text)
        # if answer == 'yes':
        #     file_mau_mat_1 = self.path2 + self.mau1
        #     os.remove(file_mau_mat_1)
        #     if self.mau2 != '':
        #         file_mau_mat_2 = self.path2 + self.mau2
        #         os.remove(file_mau_mat_2)
        #     # dong cs roi mo lai de cap nhat menu
        #     sketch.destroy()
        #     self.draw_detail(top)
        #
        # else:
        #     sketch.focus_set()
        top = Toplevel(bg='lightblue')
        top.wm_attributes('-fullscreen', 'true')
        ten_pk = self.mau_pk[0: len(self.mau_pk)-9]
        message = '\n\nXóa phụ kiện   ' + ten_pk + '   khỏi bộ nhớ?\n\n'
        L = Label(top, text=message, font='Tahoma, 20', bg='lightblue')
        L.grid(row=0, columnspan=2)
        B = Button(top, text='    Xóa    ', bg='red', font='Tahoma, 16', command=lambda: self.xoa_mau_pk(sketch, top))
        B.grid(row=1, column=0)
        B = Button(top, text='    Không    ', bg='white', font='Tahoma, 16', command=top.destroy)
        B.grid(row=1, column=1)

    def draw_detail(self, top):
        # top.destroy()
        sketch = Toplevel()
        sketch.minsize(width=self.screenwidth, height=self.screenheight)
        sketch.geometry(('{}x{}+{}+{}').format(self.screenwidth, self.screenheight, 0, 0))

        F = LabelFrame(sketch, bd=2)
        F.grid(row=0, column=0, columnspan=3)

        self.cv4 = Canvas(F, width=self.screenwidth*2/3, height=self.screenheight-80, bg='white')
        self.cv4.pack()

        F2 = LabelFrame(sketch, bd=2)
        F2.grid(row=0, column=3, columnspan=3)

        canvas_width, canvas_height =self.screenwidth/3, self.screenheight - 80
        self.cv4_2 = Canvas(F2, width=canvas_width, height=canvas_height, bg='white')
        self.cv4_2.pack()
        self.cv4_2.bind('<Button-1>', self.chon_mau_pk)

        ds_mau_pk = []
        file_mau_mat1_mat2 = os.listdir(self.path2)  # cac mau phu kien co trong data
        # print(ds_mau_pk)
        for mau_pk in file_mau_mat1_mat2:
            if '(M1)' in mau_pk:
                ds_mau_pk.append(mau_pk)  # cac mau trong cv1b
        y = 30
        for file_name in ds_mau_pk:
            file_name_rewrite = file_name.replace(' ', '^')
            name = file_name.replace('(M1).txt', '')
            frame = self.cv4_2.create_rectangle(5, y - 15, canvas_width - 5, y + 15, outline='white', fill='white', tag=file_name_rewrite)
            self.cv4_2.create_text(5, y, text=name, font='Tahoma, 11', anchor='w')
            y += 32

        # B = tkinter.Button(sketch, bg='blue4', text='<Quay lại<', fg='white', font='Tahoma, 12', command=self.back_in_cv1b)
        # B.grid(row=1, column=0)
        #
        # B = tkinter.Button(sketch, bg='blue4', text='>Mẫu khác>', fg='white', font='Tahoma, 12',
        #                    command=self.next_in_cv1b)
        # B.grid(row=1, column=1)

        B = tkinter.Button(sketch, bg='red', text='Xóa mẫu', fg='white', font='Tahoma, 12', command=lambda: self.hoi_xoa_mau_pk(sketch))
        B.grid(row=1, column=2)

        B = tkinter.Button(sketch, bg='blue4', text='Chọn', fg='white', font='Tahoma, 12', command=sketch.destroy)
        B.grid(row=1, column=3)

        B = Button(sketch, bg='blue4', text='Lên', fg='white', font='Tahoma, 12', command=lambda : self.move_canvas('cv4_2_up'))
        B.grid(row=1, column=4)

        B = Button(sketch, bg='blue4', text='Xuống', fg='white', font='Tahoma, 12', command=lambda : self.move_canvas('cv4_2_down'))
        B.grid(row=1, column=5)



    def codeManager(self):
        #self.make_current_pos() # xac dinh vi tri hien tai cua XYZE
        self.X_tim = StringVar() #tim tay khoa
        if may == 'S3': self.X_tim.set('200.0')
        else: self.X_tim.set('160.0')
        self.Y1 = StringVar()
        self.Y1.set('0.0')
        self.Z1 = StringVar()
        self.Z1.set('0.0')
        self.Z1_2 = StringVar()
        self.Z1_2.set('0.0')
        self.Z1_3 = StringVar()
        self.Z1_3.set('0.0')
        self.Z1_4 = StringVar()
        self.Z1_4.set('0.0')

        self.Y2 = StringVar()
        self.Y2.set('0.0')
        self.Z2 = StringVar()
        self.Z2.set('0.0')
        self.Z2_2 = StringVar()
        self.Z2_2.set('0.0')
        self.Z2_3 = StringVar()
        self.Z2_3.set('0.0')
        self.Z2_4 = StringVar()
        self.Z2_4.set('0.0')

        self.Y3 = StringVar()
        self.Y3.set('0.0')
        self.Z3 = StringVar()
        self.Z3.set('0.0')
        self.Z3_2 = StringVar()
        self.Z3_2.set('0.0')
        self.Z3_3 = StringVar()
        self.Z3_3.set('0.0')
        self.Z3_4 = StringVar()
        self.Z3_4.set('0.0')
        self.delta_y = StringVar()
        self.delta_y.set('205.75')
        global current_entry
        current_entry = None
        
        top = tkinter.Toplevel(self.master)
        top.minsize(width=self.screenwidth, height=self.screenheight -60)
        top.geometry(('{}x{}+{}+{}').format(self.screenwidth, self.screenheight, 0, 0))

        X_1 = self.screenwidth/6

        self.HOMEbutton = tkinter.Button(top, bg='orange', text='VỀ GỐC', fg='black', font='Tahoma, 14', command=self.home_xyz)
        self.HOMEbutton.pack()
        self.HOMEbutton.place(height=40, width=100, x=X_1-50, y=120)
        
        self.Xdecrease = tkinter.Button(top, bg='gray', text='X-', fg='black', font='Tahoma, 16')
        self.Xdecrease.pack()
        self.Xdecrease.place(height=40, width=50, x=X_1-50-20-50, y=120)
        self.Xdecrease.bind('<ButtonPress-1>', self.pButtonXdecrease)
        self.Xdecrease.bind('<ButtonRelease-1>', self.rButtonXdecrease)
        
        self.Xincrease = tkinter.Button(top, bg='gray', text='X+', fg='black', font='Tahoma, 16')
        self.Xincrease.pack()
        self.Xincrease.place(height=40, width=50, x=X_1+50+20, y=120)
        self.Xincrease.bind('<ButtonPress-1>', self.pButtonXincrease)
        self.Xincrease.bind('<ButtonRelease-1>', self.rButtonXincrease)
        
        self.Ydecrease = tkinter.Button(top, bg='pink', text='Y-', fg='black', font='Tahoma, 16')
        self.Ydecrease.pack()
        self.Ydecrease.place(height=40, width=100, x=X_1-50, y=50)
        self.Ydecrease.bind('<ButtonPress-1>', self.pButtonYdecrease)
        self.Ydecrease.bind('<ButtonRelease-1>', self.rButtonYdecrease)
        
        self.Yincrease = tkinter.Button(top, bg='pink', text='Y+', fg='black', font='Tahoma, 16')
        self.Yincrease.pack()
        self.Yincrease.place(height=40, width=100, x=X_1-50, y=190)
        self.Yincrease.bind('<ButtonPress-1>', self.pButtonYincrease)
        self.Yincrease.bind('<ButtonRelease-1>', self.rButtonYincrease)
        
        self.Zdecrease = tkinter.Button(top, bg='cyan', text='Z-', fg='black', font='Tahoma, 16')
        self.Zdecrease.pack()
        self.Zdecrease.place(height=40, width=50, x=X_1+50+20, y=50)
        self.Zdecrease.bind('<ButtonPress-1>', self.pButtonZdecrease)
        self.Zdecrease.bind('<ButtonRelease-1>', self.rButtonZdecrease)
        
        self.Zincrease = tkinter.Button(top, bg='cyan', text='Z+', fg='black', font='Tahoma, 16')
        self.Zincrease.pack()
        self.Zincrease.place(height=40, width=50, x=X_1+50+20, y=190)
        self.Zincrease.bind('<ButtonPress-1>', self.pButtonZincrease)
        self.Zincrease.bind('<ButtonRelease-1>', self.rButtonZincrease)         

        #B = tkinter.Button(top, bg='orange', text='Backup/Luu code', fg='black', font='Tahoma, 16', ancho = 'w', command='')
        #B.pack()
        #B.place(height=40, width=self.screenwidth/3, x=0, y=400)        

        frame3b = Frame(top, height=self.screenheight, width=self.screenwidth * 2/3, bg='lightgreen')
        frame3b.pack()
        frame3b.place(x=self.screenwidth/3, y=0)

        L = Label(frame3b, text='TẠO CHƯƠNG TRÌNH MỚI', font='Tahoma, 12', bg = 'lightgreen', ancho = 'w')
        L.pack()
        L.place(x=5, y=0)

        self.cv1b = Canvas(frame3b, height=90, width=self.screenwidth/2, bg = 'lightblue')
        self.cv1b.pack()
        self.cv1b.place(x=5, y=30)

        self.cv2b = Canvas(frame3b, height=90, width=self.screenwidth / 2, bg='lightblue')
        self.cv2b.pack()
        self.cv2b.place(x=5, y=120)

        # self.B = tkinter.Button(top, bg='blue4', text='>Mẫu khác>', fg='white', font='Tahoma, 12',
        #                         command=self.next_in_cv1b)
        # self.B.pack()
        # self.B.place(height=30, width=100, x=self.screenwidth - 105, y=30)
        #
        # self.B = tkinter.Button(top, bg='blue4', text='<Quay lại<', fg='white', font='Tahoma, 12',
        #                         command=self.back_in_cv1b)
        # self.B.pack()
        # self.B.place(height=30, width=100, x=self.screenwidth - 105, y=90)

        self.B = tkinter.Button(top, bg='blue4', text='Chọn mẫu\nphụ kiện', fg='white', font='Tahoma, 12',
                                command=lambda: self.draw_detail(top))
        self.B.pack()
        self.B.place(height=80, width=100, x=self.screenwidth - 110, y=130)

        frame3b0 = Frame(frame3b, height=self.screenheight / 10, width=self.screenwidth * 2 / 3, bg='lightgreen')
        frame3b0.pack()
        frame3b0.place(x=5, y=225)
        L = Label(frame3b0, text='Nhập tọa độ X của tim khóa, chốt sập, tay cài:', font='Tahoma, 12', bg='lightgreen', ancho='w')
        L.grid(row=0, column=0)
        self.Xtim_entry = Entry(frame3b0, width=5, textvariable=self.X_tim, font='Tahoma, 14')
        self.Xtim_entry.grid(row=0, column=1)
        self.Xtim_entry.bind('<Button-1>', self.select_entry)
        #Ex.focus_set()

        #mat 1
        # L = Label(frame3b, text='BƯỚC 2: Chọn hình dạng và tọa độ gia công - mặt 1:', font='Tahoma, 14', bg = 'lightgreen', ancho = 'w')
        # L.pack()
        # L.place(x=5, y=260)

        frame3b1 = Frame(frame3b, height=self.screenheight/10, width=self.screenwidth * 2/3, bg='lightgreen')
        frame3b1.pack()
        frame3b1.place(x=5, y=265)

        Label(frame3b1, text='Tọa độ mặt 1:', font='Tahoma, 12', bg='lightgreen', width=10).grid(row=0, column=0)
        
        Label(frame3b1, text='Y', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=1)
        self.Y1_entry = Entry(frame3b1, width=6, textvariable=self.Y1, font='Tahoma, 14')
        self.Y1_entry.grid(row=1, column=1)
        self.Y1_entry.bind('<Button-1>', self.select_entry)
        # Label(frame3b1, bg='lightgreen', font='Tahoma, 2').grid(row=2, column=0)
        # Button(frame3b1, text='Set', font='Tahoma, 11', bg='orange').grid(row=3, column=0)

        Label(frame3b1, text='Z', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=2)
        self.Z1_entry = Entry(frame3b1, width=6, textvariable=self.Z1, font='Tahoma, 14')
        self.Z1_entry.grid(row=1, column=2)
        self.Z1_entry.bind('<Button-1>', self.select_entry)

        Label(frame3b1, text='Z2', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=3)
        self.Z1_2_entry = Entry(frame3b1, width=6, textvariable=self.Z1_2, font='Tahoma, 14')
        self.Z1_2_entry.grid(row=1, column=3)
        self.Z1_2_entry.bind('<Button-1>', self.select_entry)

        Label(frame3b1, text='Z3', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=4)
        self.Z1_3_entry = Entry(frame3b1, width=6, textvariable=self.Z1_3, font='Tahoma, 14')
        self.Z1_3_entry.grid(row=1, column=4)
        self.Z1_3_entry.bind('<Button-1>', self.select_entry)

        Label(frame3b1, text='Z4', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=5)
        self.Z1_4_entry = Entry(frame3b1, width=6, textvariable=self.Z1_4, font='Tahoma, 14')
        self.Z1_4_entry.grid(row=1, column=5)
        self.Z1_4_entry.bind('<Button-1>', self.select_entry)

        frame3b2 = Frame(frame3b, height=self.screenheight/10, width=self.screenwidth * 2/3, bg='lightgreen')
        frame3b2.pack()
        frame3b2.place(x=5, y=320)

        Label(frame3b2, text='Tọa độ mặt 2:', font='Tahoma, 12', bg='lightgreen', width=10).grid(row=0, column=0)

        Label(frame3b2, text='Y', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=1)
        self.Y2_entry = Entry(frame3b2, width=6, textvariable=self.Y2, font='Tahoma, 14')
        self.Y2_entry.grid(row=1, column=1)
        self.Y2_entry.bind('<Button-1>', self.select_entry)
        # Label(frame3b2, bg='lightgreen', font='Tahoma, 2').grid(row=2, column=0)
        # Button(frame3b2, text='Set', font='Tahoma, 11', bg='orange').grid(row=3, column=0)

        Label(frame3b2, text='Z', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=2)
        self.Z2_entry = Entry(frame3b2, width=6, textvariable=self.Z2, font='Tahoma, 14')
        self.Z2_entry.grid(row=1, column=2)
        self.Z2_entry.bind('<Button-1>', self.select_entry)
        # Label(frame3b2, bg='lightgreen', font='Tahoma, 2').grid(row=2, column=1)
        # Button(frame3b2, text='Set', font='Tahoma, 11', bg='orange').grid(row=3, column=1)

        Label(frame3b2, text='Z2', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=3)
        self.Z2_2_entry = Entry(frame3b2, width=6, textvariable=self.Z2_2, font='Tahoma, 14')
        self.Z2_2_entry.grid(row=1, column=3)
        self.Z2_2_entry.bind('<Button-1>', self.select_entry)

        Label(frame3b2, text='Z3', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=4)
        self.Z2_3_entry = Entry(frame3b2, width=6, textvariable=self.Z2_3, font='Tahoma, 14')
        self.Z2_3_entry.grid(row=1, column=4)
        self.Z2_3_entry.bind('<Button-1>', self.select_entry)

        Label(frame3b2, text='Z4', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=5)
        self.Z2_4_entry = Entry(frame3b2, width=6, textvariable=self.Z2_4, font='Tahoma, 14')
        self.Z2_4_entry.grid(row=1, column=5)
        self.Z2_4_entry.bind('<Button-1>', self.select_entry)

        # cho phep dinh nghia lai toa do Y cua truc E
        # frame3b3 = Frame(frame3b, height=self.screenheight / 10, width=self.screenwidth * 2 / 3, bg='lightgreen')
        # frame3b3.pack()
        # frame3b3.place(x=5, y=405)
        # Label(frame3b3, text='Tọa độ Y của truc E:', font='Tahoma, 12', bg='lightgreen', anchor='e').grid(row=0,
        #                                                                                                    column=0)
        # Button(frame3b3, width=5, bg='blue4', text='-', fg='white', font='Tahoma, 9',
        #        command=lambda:self.insert_entry_delta_y('-')).grid(row=0, column=1)
        # delta_y_entry = Entry(frame3b3, width=5, textvariable=self.delta_y, font='Tahoma, 14').grid(row=0,
        #                                                                                                  column=2)
        # Button(frame3b3, width=5, bg='blue4', text='+', fg='white', font='Tahoma, 9',
        #        command=lambda:self.insert_entry_delta_y('+')).grid(row=0, column=3)

        if may == 'S3':
            frame3b4 = Frame(frame3b, height=self.screenheight / 10, width=self.screenwidth * 2 / 3, bg='lightgreen')
            frame3b4.pack()
            frame3b4.place(x=5, y=375)

            Label(frame3b4, text='Tọa độ mặt 3:', font='Tahoma, 12', bg='lightgreen', width=10).grid(row=0, column=0)

            Label(frame3b4, text='Y', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=1)
            self.Y3_entry = Entry(frame3b4, width=6, textvariable=self.Y3, font='Tahoma, 14')
            self.Y3_entry.grid(row=1, column=1)
            self.Y3_entry.bind('<Button-1>', self.select_entry)
            # Label(frame3b2, bg='lightgreen', font='Tahoma, 2').grid(row=2, column=0)
            # Button(frame3b2, text='Set', font='Tahoma, 11', bg='orange').grid(row=3, column=0)

            Label(frame3b4, text='Z', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=2)
            self.Z3_entry = Entry(frame3b4, width=6, textvariable=self.Z3, font='Tahoma, 14')
            self.Z3_entry.grid(row=1, column=2)
            self.Z3_entry.bind('<Button-1>', self.select_entry)
            # Label(frame3b2, bg='lightgreen', font='Tahoma, 2').grid(row=2, column=1)
            # Button(frame3b2, text='Set', font='Tahoma, 11', bg='orange').grid(row=3, column=1)

            Label(frame3b4, text='Z2', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=3)
            self.Z3_2_entry = Entry(frame3b4, width=6, textvariable=self.Z3_2, font='Tahoma, 14')
            self.Z3_2_entry.grid(row=1, column=3)
            self.Z3_2_entry.bind('<Button-1>', self.select_entry)
            # Label(frame3b2, bg='lightgreen', font='Tahoma, 2').grid(row=2, column=2)
            # Button(frame3b2, text='Set', font='Tahoma, 11', bg='orange').grid(row=3, column=2)

            Label(frame3b4, text='Z3', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=4)
            self.Z3_3_entry = Entry(frame3b4, width=6, textvariable=self.Z3_3, font='Tahoma, 14')
            self.Z3_3_entry.grid(row=1, column=4)
            self.Z3_3_entry.bind('<Button-1>', self.select_entry)

            Label(frame3b4, text='Z4', font='Tahoma, 12', bg='lightgreen', width=8).grid(row=0, column=5)
            self.Z3_4_entry = Entry(frame3b4, width=6, textvariable=self.Z3_4, font='Tahoma, 14')
            self.Z3_4_entry.grid(row=1, column=5)
            self.Z3_4_entry.bind('<Button-1>', self.select_entry)

        if may == 'S3':
            B = Button(top, bg='blue4', text='Khóa/mở khóa trục E', fg='white', font='Tahoma, 16',
                                command=self.khoa_truc_E)
            B.pack()
            B.place(height=40, width=self.screenwidth/3-50, x=25, y=self.screenheight-60-10-40-80)

        # B = Button(top, bg='blue4', text='Lưu chương trình', fg='white', font='Tahoma, 16',
        #                         command=lambda:self.set_filename(top))
        B = Button(top, bg='blue4', text='Lưu chương trình', fg='white', font='Tahoma, 16',
                                           command=lambda:self.sua_code_thanh_file_moi(top))
        B.pack()
        B.place(height=40, width=self.screenwidth/3-50, x=25, y=self.screenheight-60-10-40)

        B = tkinter.Button(top, bg='blue4', text='Thoát', fg='white', font='Tahoma, 16', command=top.destroy)
        B.pack()
        B.place(height=40, width=self.screenwidth/3-50, x=25, y=self.screenheight-60)

        # frame3b5 = Frame(frame3b, height=self.screenheight / 10, width=self.screenwidth * 2 / 3, bg='lightgreen')
        # frame3b5.pack()
        # frame3b5.place(x=0, y=425)
        buttons = ['.', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'C']
        X = self.screenwidth/3
        for button in buttons:
            command = lambda x=button: self.vkeyboard2_selected(x)
            # Button(frame3b5, width=4, text=button, command=command, font='Tahoma, 12').grid(row=0, column=column)
            B = Button(top, text=button, command=command, font='Tahoma, 12')
            B.pack()
            B.place(height=30, width=(self.screenwidth * 2 / 3)/12, x=X, y=440)
            X += (self.screenwidth * 2 / 3)/12

        ds_mau_pk = os.listdir(self.path2) #cac mau phu kien co trong data
        #print(ds_mau_pk)
        for mau_pk in ds_mau_pk:
            if '(M1)' in mau_pk:
                self.mau_pk_m1.append(mau_pk) #cac mau trong cv1b
            elif '(M2)' in mau_pk:
                self.mau_pk_m2.append(mau_pk) #cac mau trong cv2b
        
        return top #truyen toplevel cho ham runjog


    def xoa_file(self):
        #print(self.dirname) # thu muc (phu kien) dang duoc chon
        if self.selected_file != '':
            dialog_title = 'Tiếp tục xóa?'
            dialog_text = 'Xóa chương trình   ' + self.selected_file + '   khỏi bộ nhớ?'
            answer = messagebox.askquestion(dialog_title, dialog_text)
            if answer == 'yes':
                os.remove(self.filename)
                #loai_nhom.remove(self.selected_file)
                self.create_file_menu(self.cv2, self.dirname)
                self.create_file_menu(self.p2cv2, self.dirname)
                
        else:
            messagebox.showinfo("Lỗi!", "Chưa chọn chương trình!")

    def chon_thu_muc(self, value):
        # print(self.path + value)
        if value=='TẠO THƯ MỤC MỚI':
            self.top.destroy()
            self.them_loai_pkien('continue')
        else:
            self.dirname = value

    def new_file_folder(self, text):
        'tao hop thoai dung vkeyboard de nhap ten file folder'
    
        self.top = Toplevel()
        # self.top.minsize(width=self.screenwidth, height=self.screenheight -60)
        # self.top.geometry(('{}x{}+{}+{}').format(self.screenwidth, self.screenheight, 0, 60))
        self.top.minsize(width=self.screenwidth, height=self.screenheight)
        self.top.geometry(('{}x{}+{}+{}').format(self.screenwidth, self.screenheight, 0, 0))

        self.F = Frame(self.top)
        self.F.grid(row=0, columnspan=2)

        if text == 'password':
            appname = Label(self.F, height=2, text='NHẬP MẬT KHẨU',font =('arial', 20, 'bold'))
        elif text == 'newFolder':
            appname = Label(self.F, height=2, text='NHẬP TÊN THƯ MỤC', font =('arial', 20, 'bold'))
        elif text == 'newFile':
            appname = Label(self.F, text='NHẬP TÊN CHƯƠNG TRÌNH', font =('arial', 20, 'bold'))
        elif text == 'saveFileAs':
            appname = Label(self.F, text='NHẬP TÊN CHƯƠNG TRÌNH', font =('arial', 20, 'bold'))



        appname.grid(row=0, columnspan=10)

        if self.screenwidth == 800:
            self.box = Text(self.F, width=40, height=1, font=('arial', 18, 'bold'), wrap=WORD)
            w = 5
        else:
            self.box = Text(self.F, width=40, height=1, font=('arial', 20, 'bold'), wrap=WORD)
            w = 7
        self.box.grid(row=2, column=3, columnspan=7)

        Label(self.F, height=1).grid(row=3, columnspan=10) #dong trong tao khoang cach

        F2 = Frame(self.top)
        F2.grid(row=1, columnspan=2)
        buttons = [
            '1', '2', '3', '4', '5', '6', '7', '8', '9', '0',
            'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P',
            'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Delete',
            'Z', 'X', 'C', 'V', 'B', 'N', 'M', '-', '_', 'Backspace',
            'Space'
            ]
        varRow = 0
        varColumn = 0
        for button in buttons:
            command = lambda x = button: self.vkeyboard_selected(x)
            if varRow != 4:
                B = Button(F2, text=button, width=w, height=2, bg='black', fg='white', font='arial, 12',
                          command=command).grid(row=varRow, column=varColumn)                
            if varRow == 4:
                Button(F2, text=button, width=40, height=2, bg='black', fg='white', font='arial, 12',
                          command=command).grid(columnspan=10,row=varRow)#,column=varColumn)
            varColumn += 1
            if varColumn > 9 and varRow == 0:
                varColumn = 0
                varRow += 1
            if varColumn > 9 and varRow == 1:
                varColumn = 0
                varRow += 1
            if varColumn > 9 and varRow == 2:
                varColumn = 0
                varRow += 1
            if varColumn > 9 and varRow == 3:
                varColumn = 0
                varRow += 1
        Label(F2, height=2).grid(row=varRow+1, columnspan=10) #dong trong tao khoang cach

    def vkeyboard_selected(self, key):
        if key == 'Space':
            self.box.insert(INSERT, ' ')
        elif key == 'Delete':
             in_put = self.box.delete(1.0, END)            
        elif key == 'Tab':
            self.box.insert(INSERT, '    ')
        elif key == 'Backspace':
            self.box.delete("%s-1c" % INSERT, INSERT)
        else:
            self.box.insert(INSERT, key)

    def make_new_folder(self, text):
        new_dirname = True
        dirname = self.box.get(1.0, END)
        dirname = dirname[0: len(dirname) - 1]
        #print(dirname) #nhan duoc dirname co \n cuoi cung
        for folder in self.ds_folder:
            if dirname == folder:
                messagebox.showinfo("Lỗi!", "Thư mục này đã được tạo!")
                new_dirname = False #khong tao thu muc co ten nay
                self.top.focus_set() #dat cs toplevel len tren
        if new_dirname == True:
            os.mkdir(self.path + dirname)
            self.ds_folder.append(dirname) #them thu muc moi vao ds_folder
            self.create_dir_menu(self.cv1) #tao menu trong page1
            self.create_dir_menu(self.p2cv1) #menu trong page2
            self.top.destroy()
        if text == 'continue':
            self.dirname = dirname # cho dirname thanh menu hien hanh trong opt
            self.new_file_folder('saveFileAs')

            ten_thu_muc = StringVar()
            ten_thu_muc.set(self.dirname)
            danh_sach_thu_muc = os.listdir(self.path)  # lay ds cac thu muc trong thu muc My Documents
            danh_sach_thu_muc.append('TẠO THƯ MỤC MỚI')
            opt = OptionMenu(self.F, ten_thu_muc, *danh_sach_thu_muc, command=self.chon_thu_muc)
            opt.grid(row=2, column=0, columnspan=3)
            opt.config(width=20, font=('Tahoma', 14, 'bold'))  # co dinh kich thuoc cua optionmenu

            b = Button(self.top, text='    Tiếp tục    ', font='Tahoma, 16', command=lambda: self.saveFileAs(self.top, 'file_moi'))
            b.grid(row=9, column=0)
            Button(self.top, text='    Hủy    ', font='Tahoma, 16', command=self.top.destroy).grid(row=9, column=1)


    def them_loai_pkien(self, text):
        self.new_file_folder('newFolder') #ham new_file_folder tao ra toplevel, hop thoai ban phim ao de nhap ten
        #print('top:', top)
        if text == 'continue':
            b = Button(self.top, text='    Tiếp tục    ', font='Tahoma, 16', command=lambda: self.make_new_folder('continue'))
            b.grid(row=9,column=0)
        else:
            b = Button(self.top, text='    Tiếp tục    ', font='Tahoma, 16', command=lambda: self.make_new_folder('finish'))
            b.grid(row=9, column=0)
        Button(self.top, text='    Hủy    ', font='Tahoma, 16', command=self.top.destroy).grid(row=9,column=1)
        
        

    def xoa_pkien(self):
        print(self.dirname)
        if self.dirname != '':
            dialog_title = 'Tiếp tục xóa?'
            dialog_text = 'Xóa   ' + self.dirname + '   khỏi bộ nhớ?'
            answer = messagebox.askquestion(dialog_title, dialog_text)
            if answer == 'yes':        
                shutil.rmtree(self.path + self.dirname) #xoa tm va nd ben trong
                self.ds_folder.remove(self.dirname) #xoa trong ds_folder
                self.create_dir_menu(self.cv1) #tao menu trong page1
                self.create_dir_menu(self.p2cv1) #menu trong page2
                
        else:
            messagebox.showinfo("Lỗi!", "Chưa chọn hệ nhôm!")

        

    def p1cv1_chon_loai_pkien(self, event):
        self.chon_loai_pkien(self.cv1, event)

    def p1cv2_chon_loai_nhom(self, event):
        self.chon_loai_nhom(self.cv2, event)

    def create_password(self):
        password = self.box.get(1.0, END)
        password = password[0: len(password) - 1] #bo ky tu \n cuoi cung
        print(password)
        # if password == 'EMACNC':
        if password == '':
            self.notebook.select(self.page2_G_code_M)
            self.top.destroy()
        else:
            messagebox.showinfo("Lỗi!", "Sai mật khẩu!")

    def ask_password(self):
        self.new_file_folder('password')
        #command=lambda:self.notebook.select(self.page2_G_code_M)
        b = Button(self.top, text='    Tiếp tục    ', font='Tahoma, 16', command=self.create_password)
        b.grid(row=9,column=0)
        Button(self.top, text='    Hủy    ', font='Tahoma, 16', command=self.top.destroy).grid(row=9,column=1)

    def he_so_chinh_toc_do(self):
        # print(self.var.get())
        global he_so_chinh_toc_do
        he_so_chinh_toc_do = int(self.var.get())/100
        print(he_so_chinh_toc_do)        

    def CreateWidgets_V1V2_page1(self, page):
        pass

    def CreateWidgets_S3E3_page1(self, page):
        self.frame = Frame(page, height=self.screenheight, width=self.screenwidth, bg='blue4')
        self.frame.grid(row=0, column=0)
        self.frame1 = Frame(self.frame, height=self.screenheight-40-130, width=self.screenwidth *2/5, bg='gray')
        self.frame1.pack()
        self.frame1.place(x=0, y=40)
        self.frame2 = Frame(self.frame, height=self.screenheight-40-80-130, width=self.screenwidth *3/5, bg='gray30')
        self.frame2.pack()
        self.frame2.place(x=self.screenwidth *2/5, y=40+80)
        self.frame3 = Frame(self.frame, height=self.screenheight / 10, width=self.screenwidth *2/5, bg='blue4')
        self.frame3.pack()
        self.frame3.place(x=self.screenwidth *2/5, y=10)
        self.frame4 = Frame(self.frame, height=80, width=self.screenwidth * 3 / 5, bg='yellow')
        self.frame4.pack()
        self.frame4.place(x=self.screenwidth * 2 / 5, y=40)
        self.cv1 = Canvas(self.frame1, height=self.screenheight-40-130, width=self.screenwidth *2/5, bg='orange')
        self.cv1.pack()
        self.cv1.bind('<Button-1>', self.p1cv1_chon_loai_pkien)
        self.cv2 = Canvas(self.frame2, height=self.screenheight-40-80-130, width=self.screenwidth *3/5, bg='orange')
        self.cv2.pack()
        self.cv2.bind('<Button-1>', self.p1cv2_chon_loai_nhom)
        self.cv3 = Canvas(self.frame4, height=80, width=self.screenwidth * 3 / 5, bg='orange')
        self.cv3.pack()

        self.feedback = Text(self.frame3, height=1, width=40)
        self.feedback.grid(row=0, column=0)
        L = Label(self.frame3, bg='blue4', fg='blue4', text=' ', font='Tahoma, 6')
        L.grid(row=0, column=1)
        self.var = StringVar()
        r1 = Radiobutton(self.frame3,  text='60%', font='Tahoma,11', variable=self.var, value='60', command=self.he_so_chinh_toc_do)
        r1.grid(row=0, column=2)
        r2 = Radiobutton(self.frame3, text='100%', font='Tahoma,11', variable=self.var, value='100', command=self.he_so_chinh_toc_do)
        r2.grid(row=0, column=3)
        r3 = Radiobutton(self.frame3, text='150%', font='Tahoma,11', variable=self.var, value='150', command=self.he_so_chinh_toc_do)
        r3.grid(row=0, column=4)


        L = Label(self.frame, bg='blue4', fg='orange', text=Version, font='Tahoma, 20')
        L.pack()
        L.place(x=100, y=2)
        self.B = tkinter.Button(self.frame, bg='lightgreen', text='Lên', fg='black', font='Tahoma, 19', command=lambda : self.move_canvas('cv1_up'))
        self.B.pack()
        self.B.place(height=40, width=90, x=self.screenwidth*2/5-90, y=40)
        self.B = tkinter.Button(self.frame, bg='pink', text='Xuống', fg='black', font='Tahoma, 19', command=lambda : self.move_canvas('cv1_down'))
        self.B.pack()
        self.B.place(height=40, width=90, x=self.screenwidth*2/5-90, y=self.screenheight-130-40)
        
        self.B = tkinter.Button(self.frame, bg='lightgreen', text='Lên', fg='black', font='Tahoma, 19', command=lambda : self.move_canvas('cv2_up'))
        self.B.pack()
        self.B.place(height=40, width=90, x=self.screenwidth-90, y=40+82)

        self.B = tkinter.Button(self.frame, bg='pink', text='Xuống', fg='black', font='Tahoma, 19', command=lambda : self.move_canvas('cv2_down'))
        self.B.pack()
        self.B.place(height=40, width=90, x=self.screenwidth-90, y=self.screenheight-130-40)
        
        self.SHUTDOWN = tkinter.Button(self.frame, bg='red', text='Tắt máy', fg='black', font='Tahoma, 19', command=self.turn_off)
        self.SHUTDOWN.pack()
        self.SHUTDOWN.place(height=60, width=150, x=0, y=self.screenheight-100)
        self.MOVEXYZ = tkinter.Button(self.frame, bg='lightgreen', text='Di chuyển', font='Tahoma, 19', command=self.runjog)
        self.MOVEXYZ.pack()
        self.MOVEXYZ.place(height=60, width=130, x=(self.screenwidth-740)/4+150, y=self.screenheight-100)
        self.UPDATE = tkinter.Button(self.frame, bg='orange', text='Tùy chọn', fg='black', font='Tahoma, 19', command=self.ask_password)
        self.UPDATE.pack()
        self.UPDATE.place(height=60, width=140, x=2*(self.screenwidth-740)/4+150+130, y=self.screenheight-100)
        self.START = tkinter.Button(self.frame, bg='lightgreen', text='Bắt đầu', font='Tahoma, 19', command=self.thread_begin)
        self.START.pack()
        self.START.place(height=60, width=150, x=3*(self.screenwidth-740)/4+150+130+140, y=self.screenheight-100)
        self.RESET = tkinter.Button(self.frame, bg='red', text='Khởi động lại', fg='black', font='Tahoma, 19', command=self.reset)
        self.RESET.pack()
        self.RESET.place(height=60, width=170, x=4*(self.screenwidth-740)/4+150+130+140+150, y=self.screenheight-100)
        

    def p1cv4_chon_hanh_trinh_X(self, event):
        global hanh_trinh_X
        items = self.cv4.find_overlapping(event.x - 1, event.y - 1, event.x + 1, event.y + 1)
        # tao hieu ung danh dau menu dang duoc chon
        for selected_item in items:
            tag = self.cv4.gettags(selected_item)
            if tag != ():
                str_hanh_trinh_X = tag[0]
                if str_hanh_trinh_X in self.buttons:
                    hanh_trinh_X = float(str_hanh_trinh_X)
                    print('hanh trinh: ', hanh_trinh_X)
                    # bo chon tat ca nut nhan
                    all_items = self.cv4.find_all()
                    for item in all_items:
                        tag = self.cv4.gettags(item)
                        if tag != ():
                            if tag[0] in self.buttons:
                                self.cv4.itemconfigure(item, width=0, outline='lightgreen', fill='lightgreen')
                    # danh dau nut nhan dc chon
                    self.cv4.itemconfigure(selected_item, width=5, outline='red', fill='red')

    def CreateWidgets_M1_page1(self, page):

        self.frame = Frame(page, height=self.screenheight, width=self.screenwidth, bg='gray20')
        self.frame.grid(row=0, column=0)
        self.cv1 = Canvas(self.frame, height=self.screenheight-40-130, width=self.screenwidth /3, bg='orange')
        self.cv1.pack()
        self.cv1.place(x=0, y=40)
        self.cv1.bind('<Button-1>', self.p1cv1_chon_loai_pkien)

        self.cv2 = Canvas(self.frame, height=self.screenheight-40-130-80, width=self.screenwidth /3, bg='orange')
        self.cv2.pack()
        self.cv2.place(x=self.screenwidth /3, y=40)
        self.cv2.bind('<Button-1>', self.p1cv2_chon_loai_nhom)

        self.cv3 = Canvas(self.frame, height=self.screenheight-40-130-80, width=self.screenwidth /3, bg='orange')
        self.cv3.pack()
        self.cv3.place(x=self.screenwidth * 2 / 3, y=40)

        self.cv4 = Canvas(self.frame, height=80, width=self.screenwidth * 2 / 3, bg='orange')
        self.cv4.pack()
        self.cv4.place(x=self.screenwidth / 3, y=self.screenheight-130-80)

        self.cv4.create_text(300, 15, text='Chọn hành trình (mm)', font='Tahoma, 12', anchor='w')  # w: can le trai, e: can le phai
        self.buttons = ['460', '380', '300', '220', '150']
        x = 30
        for button in self.buttons:
            if self.buttons.index(button) == 0:
                frame = self.cv4.create_rectangle(x, 30, x + 100, 70, width=5, outline='red', fill='red',
                                                  tag=button)
            else:
                frame = self.cv4.create_rectangle(x, 30, x + 100, 70, width=0, outline='lightgreen', fill='lightgreen',
                                                  tag=button)
            self.cv4.create_text(x+35, 50, text=button, font='Tahoma, 16', anchor='w')  # w: can le trai, e: can le phai
            x += 125
        self.cv4.bind('<Button-1>', self.p1cv4_chon_hanh_trinh_X)

        self.frame3 = Frame(self.frame, height=self.screenheight / 10, width=self.screenwidth *2/5, bg='gray20')
        self.frame3.pack()
        self.frame3.place(x=self.screenwidth *2/5, y=10)

        self.feedback = Text(self.frame3, height=1, width=30, font='Tahoma, 12')
        self.feedback.grid(row=0, column=0)
        L = Label(self.frame3, bg='blue4', fg='blue4', text=' ', font='Tahoma, 6')
        L.grid(row=0, column=1)
        self.var = StringVar()
        r1 = Radiobutton(self.frame3,  text='60%', font='Tahoma,11', variable=self.var, value='60', command=self.he_so_chinh_toc_do)
        r1.grid(row=0, column=2)
        r2 = Radiobutton(self.frame3, text='100%', font='Tahoma,11', variable=self.var, value='100', command=self.he_so_chinh_toc_do)
        r2.grid(row=0, column=3)
        r3 = Radiobutton(self.frame3, text='120%', font='Tahoma,11', variable=self.var, value='120', command=self.he_so_chinh_toc_do)
        r3.grid(row=0, column=4)

        L = Label(self.frame, bg='gray20', fg='orange', text=Version, font='Tahoma, 16')
        L.pack()
        L.place(x=100, y=2)
        B = tkinter.Button(self.frame, bg='orange', text='^', fg='black', font='Tahoma, 19',
                                command=lambda: self.move_canvas('cv1_up'))
        B.pack()
        B.place(height=(self.screenheight - 40 - 130) / 2, width=30, x=self.screenwidth / 3 - 30, y=40)
        B = tkinter.Button(self.frame, bg='orange', text='v', fg='black', font='Tahoma, 19',
                                command=lambda: self.move_canvas('cv1_down'))
        B.pack()
        B.place(height=(self.screenheight - 40 - 130) / 2, width=30, x=self.screenwidth / 3 - 30,
                     y=self.screenheight - 130 - (self.screenheight - 40 - 130) / 2)

        B = tkinter.Button(self.frame, bg='orange', text='^', fg='black', font='Tahoma, 19',
                                command=lambda: self.move_canvas('cv2_up'))
        B.pack()
        B.place(height=(self.screenheight-40-130-80) / 2, width=30, x=self.screenwidth * 2 / 3 - 30, y=40)
        B = tkinter.Button(self.frame, bg='orange', text='v', fg='black', font='Tahoma, 19',
                                command=lambda: self.move_canvas('cv2_down'))
        B.pack()
        B.place(height=(self.screenheight-40-130-80) / 2, width=30, x=self.screenwidth * 2 / 3 - 30,
                     y=40 + (self.screenheight-40-130-80) / 2)


        
        # self.B = tkinter.Button(self.frame, bg='lightgreen', text='Lên', fg='black', font='Tahoma, 19', command=lambda : self.move_canvas('cv2_up'))
        # self.B.pack()
        # self.B.place(height=40, width=90, x=self.screenwidth-90, y=40+82)
        #
        # self.B = tkinter.Button(self.frame, bg='pink', text='Xuống', fg='black', font='Tahoma, 19', command=lambda : self.move_canvas('cv2_down'))
        # self.B.pack()
        # self.B.place(height=40, width=90, x=self.screenwidth-90, y=self.screenheight-130-40)
        
        self.SHUTDOWN = tkinter.Button(self.frame, bg='red', text='Tắt máy', fg='black', font='Tahoma, 19', command=self.turn_off)
        self.SHUTDOWN.pack()
        self.SHUTDOWN.place(height=60, width=150, x=0, y=self.screenheight-100)
        self.MOVEXYZ = tkinter.Button(self.frame, bg='lightgreen', text='Di chuyển', font='Tahoma, 19', command=self.runjog)
        self.MOVEXYZ.pack()
        self.MOVEXYZ.place(height=60, width=130, x=(self.screenwidth-740)/4+150, y=self.screenheight-100)
        self.UPDATE = tkinter.Button(self.frame, bg='orange', text='Tùy chọn', fg='black', font='Tahoma, 19', command=self.ask_password)
        self.UPDATE.pack()
        self.UPDATE.place(height=60, width=140, x=2*(self.screenwidth-740)/4+150+130, y=self.screenheight-100)
        self.START = tkinter.Button(self.frame, bg='lightgreen', text='Bắt đầu', font='Tahoma, 19', command=self.thread_begin)
        self.START.pack()
        self.START.place(height=60, width=150, x=3*(self.screenwidth-740)/4+150+130+140, y=self.screenheight-100)
        self.RESET = tkinter.Button(self.frame, bg='red', text='Khởi động lại', fg='black', font='Tahoma, 19', command=self.reset)
        self.RESET.pack()
        self.RESET.place(height=60, width=170, x=4*(self.screenwidth-740)/4+150+130+140+150, y=self.screenheight-100)
        

    def insert_entry(self, text):
        global current_entry
        if text == 'y1+':
            current_entry = self.E
            var = float(current_entry.get())
            var += 0.5
            current_entry.delete(0, END)
            current_entry.insert(END, str(var))
        elif text == 'y1-':
            current_entry = self.E
            var = float(current_entry.get())
            var -= 0.5
            current_entry.delete(0, END)
            current_entry.insert(END, str(var))
        elif text == 'y2+':
            current_entry = self.E2
            var = float(current_entry.get())
            var += 0.5
            current_entry.delete(0, END)
            current_entry.insert(END, str(var))
        elif text == 'y2-':
            current_entry = self.E2
            var = float(current_entry.get())
            var -= 0.5
            current_entry.delete(0, END)
            current_entry.insert(END, str(var))

    # def sua_code_trong_file(self, top):
    #     dy, dz = float(self.E.get()), 0.0
    #     f = open(self.filename, mode='r')
    #     nd_file = f.readlines()
    #     f.close()
    #     f = open(self.filename, mode='w+')
    #     f.close()
    #     f = open(self.filename, 'r+', encoding='utf-8')
    #     for line in nd_file: #xet tung dong trong file
    #         line_to_list = line.split() #chuyen dong thanh dang list
    #         for text in line_to_list: #xet tung cum ky tu trong dong
    #             if 'E90' in text:
    #                 dy, dz = float(self.E2.get()), 0.0
    #             elif 'Y' in text: #neu co chua toa do Y
    #                 text_ed = text.replace('Y', '') #loc ra gia tri toa do cua Y
    #                 if text_ed.replace('.','',1).isdigit(): #neu bo ky tu '.' ma phan con lai la 1 so
    #                     coord_Y = float(text_ed) + dy #xac dinh toa do cua Y
    #                     text_ed = 'Y' + str(format(coord_Y, '.4f'))
    #                     text = text_ed
    #             f.write(text + ' ')
    #         f.write('\n')
    #     f.close()
    #     top.destroy()

    def saveFileAs(self, top, text):
        'sua code va luu vao file moi, hoac khong sua (doi ten file)'
        if text == 'file_cu':
            new_code_file = self.filename
        elif text == 'file_moi':
            new_filename = self.box.get(1.0, END)
            new_filename = new_filename[0: len(new_filename) - 1]  # bo ky tu \n cuoi cung
            # print(filename)
            list_files = os.listdir(self.path + self.dirname)

            path = self.path + self.dirname + '/'
            # print(path) # duong dan thu muc (phu kien) dang duoc chon
            new_code_file = path + new_filename + '.gcode'  # dat ten file

        f = open(self.filename, mode='r')
        nd_file = f.readlines()
        f.close()

        f = open(new_code_file, 'w+')  # tao file
        f.close()
        #
        if may == 'M1':
            # print('saveFileAs')
            self.chon_vung_cat_cuoi()
            f = open(new_code_file, 'r+', encoding='utf-8') # sua xong luu vao file nay
            comment = '' # bien luu thong tin chu thich vung cat trong gcode
            E = 0 # cho gia tri ban dau
            for thong_tin_sua_1_vung in self.thong_tin_sua_code:
                vung_cat = 'CUT ' + thong_tin_sua_1_vung[0]
                delta_Y = float(thong_tin_sua_1_vung[1]) # gia tri can them vao khi y>80
                delta_Z = float(thong_tin_sua_1_vung[2])
                delta_E = float(thong_tin_sua_1_vung[3]) # gia tri can them vao E, tinh bang do
                # print(vung_cat, delta_Y, delta_Z, delta_E)

                for line in nd_file:
                    if ';' in line:
                        comment = line.replace(';', '')
                        comment = comment.strip()
                        # if comment == 'CUT ' + vung_cat:
                        #     print('comment = ', comment)
                        line = line[0:line.index(';')]

                    if comment == vung_cat and 'G1' in line:
                        line_to_list = line.split()
                        for text in line_to_list:
                            if 'Y' in text:
                                Y = float(text.replace('Y', ''))
                                if Y > 80.0:
                                    Y_new = Y + delta_Y
                                    print('Ynew: ', Y_new)
                                    # new_text = 'Y' + str(Y_new)
                                    new_text = 'Y' + str(format(Y_new, '.2f'))
                                    line_to_list[line_to_list.index(text)] = new_text
                            elif 'Z' in text:
                                Z = float(text.replace('Z', ''))
                                if Z > 5.0 and Z < 265:
                                    Z_new = Z + delta_Z
                                    print('Znew: ', Z_new)
                                    # new_text = 'Z' + str(Z_new)
                                    new_text = 'Z' + str(format(Z_new, '.2f'))
                                    line_to_list[line_to_list.index(text)] = new_text
                            elif 'E' in text:
                                E = float(text.replace('E', ''))
                                E_new = E + delta_E
                                print('Enew: ', E_new)
                                # new_text = 'E' + str(E_new)
                                new_text = 'E' + str(format(E_new, '.2f'))
                                line_to_list[line_to_list.index(text)] = new_text
                        new_line = ''
                        for text in line_to_list:
                            new_line += text + ' '
                        # print('line edited: ', new_line)
                        nd_file[nd_file.index(line)] = new_line + '\n'
            # print(nd_file)
            for line in nd_file:
                f.write(line)
            f.close()
            self.top.destroy()
            top.destroy()
            self.thong_tin_sua_code.clear()

        else:
            # new_filename = self.box.get(1.0, END)
            # new_filename = new_filename[0: len(new_filename) - 1]  # bo ky tu \n cuoi cung
            # # print(filename)
            # list_files = os.listdir(self.path + self.dirname)
            #
            # path = self.path + self.dirname + '/'
            # # print(path) # duong dan thu muc (phu kien) dang duoc chon
            # new_code_file = path + new_filename + '.gcode'  # dat ten file
            #
            # f = open(self.filename, mode='r')
            # nd_file = f.readlines()
            # f.close()
            #
            # f = open(new_code_file, 'w+')  # tao file
            # f.close()
            f = open(new_code_file, 'r+', encoding='utf-8')
            dy, dz = float(self.E.get()), 0.0
            for line in nd_file:  # xet tung dong trong file
                line_to_list = line.split()  # chuyen dong thanh dang list
                for text in line_to_list:  # xet tung cum ky tu trong dong
                    if 'E90' in text:
                        dy, dz = float(self.E2.get()), 0.0
                    elif 'Y' in text:  # neu co chua toa do Y
                        text_ed = text.replace('Y', '')  # loc ra gia tri toa do cua Y
                        if text_ed.replace('.', '', 1).isdigit():  # neu bo ky tu '.' ma phan con lai la 1 so
                            coord_Y = float(text_ed) + dy  # xac dinh toa do cua Y
                            text_ed = 'Y' + str(format(coord_Y, '.4f'))
                            text = text_ed
                    f.write(text + ' ')
                f.write('\n')
            f.close()
            # loai_nhom.append(new_filename)
            # self.create_file_menu(self.cv2, self.dirname)  # tao menu trong page1
            # self.create_file_menu(self.p2cv2, self.dirname)  # menu trong page2
            self.top.destroy()
            top.destroy()

    def sua_code_thanh_file_moi(self, top):
        'tao hop thoai de nhap ten file moi'
        # top.destroy() #dong cua so 'sua_code_nhanh'

        self.new_file_folder('saveFileAs')#ham new_file_folder tao ra toplevel, hop thoai ban phim ao de nhap ten

        ten_thu_muc = StringVar()
        ten_thu_muc.set(self.dirname)
        danh_sach_thu_muc = os.listdir(self.path)  # lay ds cac thu muc trong thu muc My Documents
        danh_sach_thu_muc.append('TẠO THƯ MỤC MỚI')
        opt = OptionMenu(self.F, ten_thu_muc, *danh_sach_thu_muc, command=self.chon_thu_muc)
        opt.grid(row=2, column=0, columnspan=3)
        opt.config(width=20, font=('Tahoma', 14, 'bold'))  # co dinh kich thuoc cua optionmenu

        #print('top:', top)
        if may == 'M1':
            b = Button(self.top, text='    Tiếp tục    ', font='Tahoma, 16', command=lambda:self.saveFileAs(top, 'file_moi'))
            b.grid(row=9,column=0)
        else:
            b = Button(self.top, text='    Tiếp tục    ', font='Tahoma, 16', command=lambda: self.make_new_file(top))
            b.grid(row=9, column=0)

        Button(self.top, text='    Hủy    ', font='Tahoma, 16', command=self.top.destroy).grid(row=9,column=1)


    def sua_code_may_phay_khoa(self):
        try:
            print(self.dirname, self.selected_file)
            print(self.filename)
            y1=StringVar()
            y1.set('0')
            y2=StringVar()
            y2.set('0')
            top = tkinter.Toplevel()
            # top.geometry(('{}x{}+{}+{}').format(self.screenwidth, self.screenheight, 0, 60))
            top.wm_attributes('-fullscreen', 'true')
            file = self.dirname + ' \\ ' + self.selected_file
            L = Label(top, text='\nSỬA CHƯƠNG TRÌNH:\n' + file + '\n', font='Tahoma, 16').pack()
            F = Frame(top, width=self.screenwidth, height=self.screenheight/4)
            F.pack()
            L = Label(F, height=2, text='TỌA ĐỘ Y CỦA MẶT 1:', font='Tahoma, 16', anchor='e')
            L.grid(row=0, column=0)
            Button(F, width=10, text='-', font='Tahoma, 16', command=lambda: self.insert_entry('y1-')).grid(row=0, column=1)
            self.E = Entry(F, width=5, textvariable=y1, font='Tahoma, 24')
            self.E.grid(row=0, column=2)
            Button(F, width=10, text='+', font='Tahoma, 16', command=lambda: self.insert_entry('y1+')).grid(row=0, column=3)

            L = Label(F, height=2, text='TỌA ĐỘ Y CỦA MẶT 2:', font='Tahoma, 16', anchor='e')
            L.grid(row=1, column=0)
            Button(F, width=10, text='-', font='Tahoma, 16', command=lambda: self.insert_entry('y2-')).grid(row=1, column=1)
            self.E2 = Entry(F, width=5, textvariable=y2, font='Tahoma, 24')
            self.E2.grid(row=1, column=2)
            Button(F, width=10, text='+', font='Tahoma, 16', command=lambda: self.insert_entry('y2+')).grid(row=1, column=3)

            # L = Label(F, height=2, text='TỐC ĐỘ CHẠY CẮT:', font='Tahoma, 16', anchor='e')
            # L.grid(row=2, column=0)
            # Button(F, width=10, text='-', font='Tahoma, 16', command=lambda: self.insert_entry('f-')).grid(row=2, column=1)
            # self.E2 = Entry(F, width=5, textvariable='', font='Tahoma, 24')
            # self.E2.grid(row=2, column=2)
            # Button(F, width=10, text='+', font='Tahoma, 16', command=lambda: self.insert_entry('f+')).grid(row=2, column=3)

            b = Button(F, text='LƯU LẠI', font='Tahoma, 16', command=lambda:self.saveFileAs(top, 'file_cu'))
            b.grid(row=3, column=0) #, columnspan=2)
            b = Button(F, text='LƯU TÊN KHÁC', font='Tahoma, 16', command=lambda: self.sua_code_thanh_file_moi(top))
            b.grid(row=3, column=1)  # , columnspan=2)
            #b.pack()
            #b.place(width=150, height=50, x=350, y=self.screenheight-70)

            b = Button(F, text='HỦY', font='Tahoma, 16', command=top.destroy)
            b.grid(row=3, column=2, columnspan=2)
            #b.pack()
            #b.place(width=150, height=50, x=500, y=self.screenheight-70)

            #tim toa do Y,Z trong code (lay thong so de chinh sua code chi tiet)
            #hien tai moi chi dang lay ket qua de hien thi ra man hinh
            Y1, Y2 = 0.0, 0.0 # toa do Y cuar mat 1 va mat 2
            f = open(self.filename, mode='r')
            nd_file = f.readlines()
            f.close()
            points_y = []  # list cac toa do y
            mat = 'mat_1'
            for nd_dong_i in nd_file:  # xet tung dong trong file
                if 'G1' in nd_dong_i and 'E90' in nd_dong_i:
                    mat = 'mat_2'
                elif 'G1' in nd_dong_i and 'E-90' in nd_dong_i:
                    mat = 'mat_3'
                if 'G1' in nd_dong_i and 'X' in nd_dong_i and 'Y' in nd_dong_i: # them toa do vao polygon
                    # print(nd_dong_i)
                    dong_i = nd_dong_i.split()

                    text = dong_i[2]
                    text_ed = text.replace('Y', '')
                    if text_ed.replace('.', '', 1).isdigit():  # neu bo ky tu '.' ma phan con lai la 1 so
                        Y = float(text_ed)  # xac dinh toa do cua Y
                    points_y.append(Y)
                elif 'G1' in nd_dong_i and 'Z' in nd_dong_i:
                    # print(nd_dong_i)
                    if len(points_y) >= 2:
                        Ymin, Ymax = 1000.0, 0.0
                        for Y in points_y:
                            if Y < Ymin: Ymin = Y
                            if Y > Ymax: Ymax = Y
                        # print('Ymin:', Ymin, 'Ymax:', Ymax, 'Y:', (Ymin+Ymax)/2)
                        Y_tb = (Ymin+Ymax)/2 #trung binh giua min max
                        if Y_tb > 0 and  mat == 'mat_1': Y1 = Y_tb
                        elif Y_tb > 0 and mat == 'mat_2': Y2 = Y_tb
                    points_y.clear()

            # Label(F, text='Y1 = ' + str(Y1), font='Tahoma, 16').grid(row=3, column=0)
            # Label(F, text='Y2 = ' + str(Y2), font='Tahoma, 16').grid(row=3, column=2)

        except:
            messagebox.showinfo("Lỗi!", "CHUA CHON FILE!")

    def chon_vung_cat_cuoi(self):
        if self.vung_cat_truoc == '':
            messagebox.showinfo("Lỗi!", "CHƯA CHỌN VÙNG ĐIỀU CHỈNH!")
        else:
            delta_Y = self.dieu_chinh_Y.get()
            delta_Z = self.dieu_chinh_Z.get()
            delta_E = self.dieu_chinh_E.get()
            vung_cat_da_luu = []  # list chua ten cua cac vung cat da luu trong thong_tin_sua_code
            for thong_tin_sua_1_vung in self.thong_tin_sua_code:
                vung_cat_da_luu.append(thong_tin_sua_1_vung[0])
            if self.vung_cat_truoc in vung_cat_da_luu:
                for thong_tin_sua_1_vung in self.thong_tin_sua_code:
                    if self.vung_cat_truoc == thong_tin_sua_1_vung[0]:
                        thong_tin_sua_1_vung[1] = delta_Y
                        thong_tin_sua_1_vung[2] = delta_Z
                        thong_tin_sua_1_vung[3] = delta_E
            else:
                self.thong_tin_sua_code.append([self.vung_cat_truoc, delta_Y, delta_Z, delta_E])
            print('thong tin sua code: ', self.thong_tin_sua_code)

    def chon_vung_cat(self, event):
        ''
        item = self.cv5.find_closest(event.x, event.y)[0]
        tags = self.cv5.gettags(item)
        # print(tags)
        if 'cut' in tags:
            vung_cat = tags[1]
            # print('vung cat: ', vung_cat)
            self.cv5.itemconfigure('cut', fill='blue') # cho tat ca cac vung cat thanh mau xanh
            self.cv5.itemconfigure(vung_cat, fill='red') # cho vung cat dang duoc chon thanh mau do
            # items_selected = self.cv5.find_withtag(vung_cat) # cac doi tuong trong vung cat dang chon
            # print(items_selected)
            delta_Y = self.dieu_chinh_Y.get()
            delta_Z = self.dieu_chinh_Z.get()
            delta_E = self.dieu_chinh_E.get()
            if self.vung_cat_truoc == '':# luu vao vung cat hien tai
                self.thong_tin_sua_code.append([vung_cat, delta_Y, delta_Z, delta_E])

            else: # neu dang chon 1 vung cat ma chuyen sang vung cat khac
                'luu gia gi trong cac entry vao vung cat vua roi khoi, cho hien lai gia tri dieu chinh da luu trong vung cat vua chuyen den'
                # luu gia tri trong cac entry vao vung cat vua roi khoi
                # delta_Y = self.dieu_chinh_Y.get()
                # delta_Z = self.dieu_chinh_Z.get()
                # delta_E = self.dieu_chinh_E.get()
                # if self.thong_tin_sua_code == []: # chua sua vung nao
                #     self.thong_tin_sua_code.append([self.vung_cat_truoc, delta_Y, delta_Z, delta_E])
                # else:
                'ghi lai thong tin vao vung cat vua roi di, ghi de neu da co, chua co thi tao moi'
                vung_cat_da_luu = [] # list chua ten cua cac vung cat da luu trong thong_tin_sua_code
                for thong_tin_sua_1_vung in self.thong_tin_sua_code:
                    vung_cat_da_luu.append(thong_tin_sua_1_vung[0])
                if self.vung_cat_truoc in vung_cat_da_luu:
                    for thong_tin_sua_1_vung in self.thong_tin_sua_code:
                        if self.vung_cat_truoc == thong_tin_sua_1_vung[0]:
                            thong_tin_sua_1_vung[1] = delta_Y
                            thong_tin_sua_1_vung[2] = delta_Z
                            thong_tin_sua_1_vung[3] = delta_E
                else:
                    self.thong_tin_sua_code.append([self.vung_cat_truoc, delta_Y, delta_Z, delta_E])

                vung_cat_da_luu = []  # list chua ten cua cac vung cat da luu trong thong_tin_sua_code
                for thong_tin_sua_1_vung in self.thong_tin_sua_code:
                    vung_cat_da_luu.append(thong_tin_sua_1_vung[0])
                print('vung cat da luu: ', vung_cat_da_luu)
                if vung_cat in vung_cat_da_luu:
                    for thong_tin_sua_1_vung in self.thong_tin_sua_code:
                        if vung_cat == thong_tin_sua_1_vung[0]:
                            self.dieu_chinh_Y.set(thong_tin_sua_1_vung[1])
                            self.dieu_chinh_Z.set(thong_tin_sua_1_vung[2])
                            self.dieu_chinh_E.set(thong_tin_sua_1_vung[3])
                else:
                    self.dieu_chinh_Y.set(0.0)
                    self.dieu_chinh_Z.set(0.0)
                    self.dieu_chinh_E.set(0.0)
            # print('thong tin sua code: ', self.thong_tin_sua_code)
            self.vung_cat_truoc = vung_cat


    def xoa_entry(self):
        try:
            current_entry.delete(0, END)
            current_entry.insert(0, '0.0')
        except:  # khong chon vao entry
            print('not selected entry!')

    def sua_code_may_phay_do(self):
        # print(self.dirname, self.selected_file)
        # print(self.filename)
        # self.toa_do_Y_cu, self.toa_do_Z_cu, self.toa_do_E_cu = StringVar(), StringVar(), StringVar()
        # self.toa_do_Y_cu.set(0)
        self.thong_tin_sua_code.clear()
        self.dieu_chinh_Y, self.dieu_chinh_Z, self.dieu_chinh_E = StringVar(), StringVar(), StringVar()
        self.dieu_chinh_Y.set(0.0)
        self.dieu_chinh_Z.set(0.0)
        self.dieu_chinh_E.set(0.0)

        top = tkinter.Toplevel()
        # top.geometry(('{}x{}+{}+{}').format(self.screenwidth, self.screenheight, 0, 0))
        top.wm_attributes('-fullscreen', 'true')
        file = self.dirname + ' \\ ' + self.selected_file
        L = Label(top, text='SỬA CHƯƠNG TRÌNH: '+ file, font='Tahoma, 12')
        # L.grid(row=0, columnspan=2)
        L.pack()
        frame = LabelFrame(top, bd=2)
        # frame.grid(row=1, column=0)
        frame.pack()
        # frame.place(x=10, y=30)
        F = LabelFrame(frame, bd=2)
        F.grid(row=0, column=0, rowspan=3)
        canvas_width, canvas_height = self.screenwidth*2/3, self.screenheight-70 # kt canvas
        self.cv5 = Canvas(F, width=canvas_width, height=canvas_height, bg='gray10')
        # self.cv5.pack()
        self.cv5.pack()
        self.cv5.bind('<Button-1>', self.chon_vung_cat)
        self.draw_section(self.cv5)
        # self.cv5.itemconfigure('polygon_trong', fill='gray10')
        # self.cv5.itemconfigure('polygon_ngoai', fill='white', outline='white', width=0)
        self.cv5.delete('polygon_trong')
        self.cv5.delete('polygon_ngoai')
        # di chuyen hinh ve giua canvas
        # self.cv5.scale('all', 0, 0, 3, 3)
        coords = self.cv5.bbox('all')
        if coords != None:
            h = coords[3] - coords[1] # chieu cao mat cat
            n = 0.8 * (canvas_height / h) # ti le zoom
            xt, yt = (coords[0] + coords[2]) / 2, (coords[1] + coords[3]) / 2
            xt_canvas, yt_canvas = canvas_width / 2, canvas_height / 2
            self.cv5.move('all', xt_canvas - xt, yt_canvas - yt) # di chuyen hinh ve giua canvas
            self.cv5.scale('all', xt_canvas, yt_canvas, n, n)
            self.cv5.create_text(canvas_width*2/3, 25, text='Y+ ------------ Y-', font='Tahoma, 18', fill='white')
            self.cv5.create_text(canvas_width - 25, canvas_height / 3, text='Z-\n\n|\n|\n|\n\nZ+', font='Tahoma, 18', fill='white')
            self.cv5.create_arc(canvas_width-100, canvas_height-100, canvas_width+100, canvas_height+100, start=0, extent=180, outline='white')
            self.cv5.create_text(canvas_width -25, canvas_height - 125, text='E-', font='Tahoma, 18', fill='white')
            self.cv5.create_text(canvas_width - 125, canvas_height - 25, text='E+', font='Tahoma, 18', fill='white')

        # F = LabelFrame(top, text=file, bd=2)
        # # F.grid(row=1, column=1)
        # F.pack()
        # F.place(x=self.screenwidth*2/3, y=30)

        F2 = Frame(frame)
        F2.grid(row=0, column=1)
        # Label(F2, text='\nTọa độ hiện tại', font='Tahoma, 14').grid(row=0, columnspan=3)
        # Label(F2, width=10, text='Y', font='Tahoma, 12').grid(row=1, column=0)
        # Label(F2, width=10, text='Z', font='Tahoma, 12').grid(row=1, column=1)
        # Label(F2, width=10, text='E', font='Tahoma, 12').grid(row=1, column=2)
        # Entry(F2, width=6, font='Tahoma, 12', textvariable=self.toa_do_Y_cu, state=DISABLED).grid(row=2, column=0)
        # Entry(F2, width=6, font='Tahoma, 12', textvariable=self.toa_do_Z_cu, state=DISABLED).grid(row=2, column=1)
        # Entry(F2, width=6, font='Tahoma, 12', textvariable=self.toa_do_E_cu, state=DISABLED).grid(row=2, column=2)
        # Label(F2, text='                ', font='Tahoma, 14').grid(row=0, column=3)
        Label(F2, text='Điều chỉnh vùng chọn màu đỏ', font='Tahoma, 16').grid(row=0, column=0,columnspan=2)

        Label(F2, width=10, text='Y (mm)', font='Tahoma, 16', anchor='w').grid(row=1, column=0)
        Label(F2, width=10, text='Z (mm)', font='Tahoma, 16', anchor='w').grid(row=2, column=0)
        Label(F2, width=10, text='E (độ)', font='Tahoma, 16', anchor='w').grid(row=3, column=0)

        # Button(F2, width=5, text='+').grid(row=2, column=4)
        E = Entry(F2, width=6, font='Tahoma, 16', textvariable=self.dieu_chinh_Y) # state=DISABLED)
        E.grid(row=1, column=1)
        E.bind('<Button-1>', self.select_entry)
        # Button(F2, width=5, text='-').grid(row=2, column=6)

        # Button(F2, width=5, text='+').grid(row=2, column=7)
        E = Entry(F2, width=6, font='Tahoma, 16', textvariable=self.dieu_chinh_Z)
        E.grid(row=2, column=1)
        E.bind('<Button-1>', self.select_entry)
        # Button(F2, width=5, text='-').grid(row=2, column=9)

        # Button(F2, width=5, text='+').grid(row=2, column=10)
        E = Entry(F2, width=6, font='Tahoma, 16', textvariable=self.dieu_chinh_E)
        E.grid(row=3, column=1)
        E.bind('<Button-1>', self.select_entry)
        # Button(F2, width=5, text='-').grid(row=2, column=12)

        Button(F2, width=6, text='Xóa', font='Tahoma, 16', command=self.xoa_entry).grid(row=4, column=1)
        Label(F2, font='Tahome, 6').grid(row=5, column=0)  # tao khoang cach

        F3 = Frame(frame)
        F3.grid(row=1,column=1)

        buttons = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '.', '-']
        row, column = 0, 0
        for button in buttons:
            command = lambda x=button: self.vkeyboard2_selected(x)
            B = Button(F3, width=5, text=button, command=command, font='Tahoma, 18', bg='gray20', fg='white')
            B.grid(row=row, column=column)
            column += 1
            if column == 3:
                column = 0
                row += 1
        Label(F3, font='Tahome, 6').grid(row=row, column=0) # tao khoang cach


        F4 = Frame(frame)
        F4.grid(row=2, column=1)

        Button(F4, width=15, text='Lưu lại', font='Tahoma, 16', command= lambda: self.saveFileAs(top, 'file_cu')).grid(row=0, column=0)
        Label(F4, font='Tahome, 6').grid(row=1, column=0)
        Button(F4, width=15, text='Lưu tên khác', font='Tahoma, 16', command=lambda: self.sua_code_thanh_file_moi(top)).grid(row=2, column=0)
        Label(F4, font='Tahome, 6').grid(row=3, column=0)
        Button(F4, width=15, text='Hủy', font='Tahoma, 16', command=top.destroy).grid(row=4, column=0)
        Label(F4, font='Tahome, 6').grid(row=5, column=0)  # tao khoang cach




    def sua_code_nhanh(self):
        if may == 'M1': self.sua_code_may_phay_do()
        else: self.sua_code_may_phay_khoa()

    def p2cv1_chon_loai_pkien(self, event):
        self.chon_loai_pkien(self.p2cv1, event)


    def p2cv2_chon_loai_nhom(self, event):
        self.chon_loai_nhom(self.p2cv2, event)

    def CreateWidgets_page2(self, page):

        if may == 'M1':
            self.p2frame = Frame(page, height=self.screenheight, width=self.screenwidth, bg='gray20')
            self.p2frame.grid(row=0, column=0)
            self.p2cv1 = Canvas(self.p2frame, height=self.screenheight - 40 - 130, width=self.screenwidth / 3, bg='orange')
            self.p2cv1.pack()
            self.p2cv1.place(x=0, y=40)
            self.p2cv1.bind('<Button-1>', self.p2cv1_chon_loai_pkien)

            self.p2cv2 = Canvas(self.p2frame, height=self.screenheight - 40 - 130, width=self.screenwidth / 3,
                              bg='orange')
            self.p2cv2.pack()
            self.p2cv2.place(x=self.screenwidth / 3, y=40)
            self.p2cv2.bind('<Button-1>', self.p2cv2_chon_loai_nhom)

            self.p2cv3 = Canvas(self.p2frame, height=self.screenheight - 40 - 130, width=self.screenwidth / 3,
                              bg='orange')
            self.p2cv3.pack()
            self.p2cv3.place(x=self.screenwidth * 2 / 3, y=40)

            self.p2feedback = Text(self.p2frame, height=1, width=50)
            self.p2feedback.pack()
            self.p2feedback.place(x=self.screenwidth * 2 / 5, y=10)

            B = tkinter.Button(self.p2frame, bg='orange', text='^', fg='black', font='Tahoma, 19',
                               command=lambda: self.move_canvas('p2cv1_up'))
            B.pack()
            B.place(height=(self.screenheight - 40 - 130) / 2, width=30, x=self.screenwidth / 3 - 30, y=40)
            B = tkinter.Button(self.p2frame, bg='orange', text='v', fg='black', font='Tahoma, 19',
                               command=lambda: self.move_canvas('p2cv1_down'))
            B.pack()
            B.place(height=(self.screenheight - 40 - 130) / 2, width=30, x=self.screenwidth / 3 - 30,
                    y=self.screenheight - 130 - (self.screenheight - 40 - 130) / 2)


            B = tkinter.Button(self.p2frame, bg='orange', text='^', fg='black', font='Tahoma, 19',
                               command=lambda: self.move_canvas('p2cv2_up'))
            B.pack()
            B.place(height=(self.screenheight - 40 - 130) / 2, width=30, x=self.screenwidth * 2 / 3 - 30, y=40)
            B = tkinter.Button(self.p2frame, bg='orange', text='v', fg='black', font='Tahoma, 19',
                               command=lambda: self.move_canvas('p2cv2_down'))
            B.pack()
            B.place(height=(self.screenheight - 40 - 130) / 2, width=30, x=self.screenwidth * 2 / 3 - 30,
                    y=self.screenheight - 130 - (self.screenheight - 40 - 130) / 2)
        else:
            self.p2frame = Frame(page, height=self.screenheight, width=self.screenwidth, bg='blue4')
            self.p2frame.grid(row=0, column=0)
            self.p2frame1 = Frame(self.p2frame,  height=self.screenheight-40-130, width=self.screenwidth *2/5, bg='gray')
            self.p2frame1.pack()
            self.p2frame1.place(x=0, y=40)
            self.p2frame2 = Frame(self.p2frame, height=self.screenheight-40-130, width=self.screenwidth *3/5, bg='gray30')
            self.p2frame2.pack()
            self.p2frame2.place(x=self.screenwidth *2/5, y=40)
            self.p2frame3 = Frame(self.p2frame, height=self.screenheight / 10, width=self.screenwidth *3/5, bg='yellow')
            self.p2frame3.pack()
            self.p2frame3.place(x=self.screenwidth *2/5, y=10)
            self.p2cv1 = Canvas(self.p2frame1, height=self.screenheight-40-130, width=self.screenwidth *2/5, bg='orange')
            self.p2cv1.pack()
            self.p2cv1.bind('<Button-1>', self.p2cv1_chon_loai_pkien)
            self.p2cv2 = Canvas(self.p2frame2, height=self.screenheight-40-130, width=self.screenwidth *3/5, bg='orange')
            self.p2cv2.pack()
            self.p2cv2.bind('<Button-1>', self.p2cv2_chon_loai_nhom)
            self.p2feedback = Text(self.p2frame3, height=1, width=50)
            self.p2feedback.pack()

            self.B = tkinter.Button(self.p2frame, bg='lightgreen', text='Lên', fg='black', font='Tahoma, 19', command=lambda : self.move_canvas('p2cv1_up'))
            self.B.pack()
            self.B.place(height=40, width=90, x=self.screenwidth*2/5-90, y=40)
            self.B = tkinter.Button(self.p2frame, bg='pink', text='Xuống', fg='black', font='Tahoma, 19', command=lambda : self.move_canvas('p2cv1_down'))
            self.B.pack()
            self.B.place(height=40, width=90, x=self.screenwidth*2/5-90, y=self.screenheight-130-40)

            self.B = tkinter.Button(self.p2frame, bg='lightgreen', text='Lên', fg='black', font='Tahoma, 19',
                                    command=lambda: self.move_canvas('p2cv2_up'))
            self.B.pack()
            self.B.place(height=40, width=90, x=self.screenwidth - 90, y=40)

            self.B = tkinter.Button(self.p2frame, bg='pink', text='Xuống', fg='black', font='Tahoma, 19',
                                    command=lambda: self.move_canvas('p2cv2_down'))
            self.B.pack()
            self.B.place(height=40, width=90, x=self.screenwidth - 90, y=self.screenheight - 130 - 40)
        
        self.B = tkinter.Button(self.p2frame, bg='white', text='Thêm\nthư mục', fg='black', font='Tahoma, 19', command=lambda: self.them_loai_pkien('finish'))
        self.B.pack()
        self.B.place(height=80, width=110, x=0, y=self.screenheight-100)

        self.B = tkinter.Button(self.p2frame, bg='white', text='Xóa\nthư mục', fg='black', font='Tahoma, 19', command=self.xoa_pkien)
        self.B.pack()
        self.B.place(height=80, width=110, x=(self.screenwidth-745)/6+110, y=self.screenheight-100)

        self.B = tkinter.Button(self.p2frame, bg='white', text='Cập\nnhật', fg='black', font='Tahoma, 19', command=self.ask_update_copy)
        self.B.pack()
        self.B.place(height=80, width=80, x=2*(self.screenwidth-745)/6+110+110, y=self.screenheight-100)

        self.B = tkinter.Button(self.p2frame, bg='lightgreen', text='< Bảng\nđiều khiển', fg='black', font='Tahoma, 19', command=lambda:self.notebook.select(self.page1_control))
        self.B.pack()
        self.B.place(height=80, width=145, x=3*(self.screenwidth-745)/6+110+110+80, y=self.screenheight-100)
        


        self.B_newFile = tkinter.Button(self.p2frame, bg='white', text='Thêm\nCh.trình', fg='black', font='Tahoma, 19', command=self.codeManager)
        self.B_newFile.pack()
        self.B_newFile.place(height=80, width=100, x=4*(self.screenwidth-745)/6+110+110+80+145, y=self.screenheight-100)
        self.B_newFile.configure(state='disabled')

        self.B = tkinter.Button(self.p2frame, bg='white', text='Xóa\nCh.trình', fg='black', font='Tahoma, 19', command=self.xoa_file)
        self.B.pack()
        self.B.place(height=80, width=100, x=5*(self.screenwidth-745)/6+110+110+80+145+100, y=self.screenheight-100)

        self.B = tkinter.Button(self.p2frame, bg='white', text='Sửa\nCh.trình', fg='black', font='Tahoma, 19', command=self.sua_code_nhanh)
        self.B.pack()
        self.B.place(height=80, width=100, x=6*(self.screenwidth-745)/6+110+110+80+145+100+100, y=self.screenheight-100)

##if __name__ == '__main__':
##    guiFrame = GUIFramework()
##    guiFrame.tao_ds_folder()
##    guiFrame.create_dir_menu(guiFrame.cv1) #tao menu trong page1
##    guiFrame.create_dir_menu(guiFrame.p2cv1) #menu trong page2
##    thread_runJog = threading.Thread(target=guiFrame.holdDownButton, args=())
##    thread.start()
##    connectSerial()
##    guiFrame.mainloop()


guiFrame = GUIFramework()
guiFrame.tao_ds_folder()
guiFrame.create_dir_menu(guiFrame.cv1) #tao menu trong page1
guiFrame.create_dir_menu(guiFrame.p2cv1) #menu trong page2
thread_runJog = threading.Thread(target=guiFrame.holdDownButton, args=())
thread.start()
try:
    ser.port = '/dev/ttyACM0'
    ser.open()
    connectSerial()
except:
    try:
        ser.port = '/dev/ttyUSB0'
        ser.open()
        connectSerial()
    except:
        try:
            ser.port = 'com90'
            ser.open()
            connectSerial()
        except:
            pass
            loi_ket_noi()

guiFrame.mainloop()
call.mainloop()